var enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager =
[
    [ "LiveWallpaperLogInterface", "d6/de8/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface.html", "d6/de8/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface" ],
    [ "getInstance", "db/d2b/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager.html#aebcac24fe2c0b8349e3d571d77f917ab", null ],
    [ "getLogInterface", "db/d2b/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager.html#aa8ae2e555ed4157a6fc9823c62710bd8", null ],
    [ "hasExternalLogger", "db/d2b/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager.html#a5267d947237ddf37005009a3d940a6b4", null ],
    [ "setLogInterface", "db/d2b/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager.html#a73330631421f051ed2a9fb49e09d9758", null ],
    [ "INSTANCE", "db/d2b/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager.html#ae2e1bde512fab8581dd72e9a7d015846", null ]
];