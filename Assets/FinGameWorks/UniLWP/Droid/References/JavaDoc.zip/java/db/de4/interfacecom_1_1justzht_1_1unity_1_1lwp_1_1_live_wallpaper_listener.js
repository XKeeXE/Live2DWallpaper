var interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener =
[
    [ "DarkModeEnableUpdated", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#a3ad03e69bc6f59c72bd32c3a42f7c280", null ],
    [ "EnterActivityUpdated", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#a8652299d11786bf46270cbe2b779f885", null ],
    [ "InsetsUpdated", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#aedf26beeb2cd7abf0ffaf2093d473d15", null ],
    [ "ScreenDisplayStatusUpdated", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#af0a429001523409a7f8ecf3348ceb299", null ],
    [ "ServiceIsInPreviewUpdated", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#ad0b7f7ba8f98011a0f10691b9e964bda", null ],
    [ "SettingsButtonPressed", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#abeb20bd84b0a58e35b7eba822254b21d", null ],
    [ "WallpaperOffsetsUpdated", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#aeed0f7fcdda5a0f5d935b8cc2408e743", null ]
];