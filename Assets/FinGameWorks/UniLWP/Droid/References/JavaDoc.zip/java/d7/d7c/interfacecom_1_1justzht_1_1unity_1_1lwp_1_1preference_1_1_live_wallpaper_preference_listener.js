var interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener =
[
    [ "PreferenceUpdated", "d7/d7c/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener.html#a5ada6dc0def8af3cb7808cd51e860f79", null ],
    [ "PreferenceUpdated", "d7/d7c/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener.html#a4d063797207418e5dad40e7db5721cc5", null ],
    [ "PreferenceUpdated", "d7/d7c/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener.html#a3eaa1149d104b1e4bf67a8aa2b81400e", null ],
    [ "PreferenceUpdated", "d7/d7c/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener.html#ab94c41d64abe3224ab66b1fed47110c3", null ]
];