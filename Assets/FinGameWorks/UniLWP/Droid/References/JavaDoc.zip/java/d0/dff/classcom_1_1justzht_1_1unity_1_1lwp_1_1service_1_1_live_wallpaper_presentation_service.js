var classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service =
[
    [ "LiveWallpaperPresentationServiceEngine", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0" ],
    [ "onConfigurationChanged", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#a7ad1da82c9a1f12c22f0a170beb8f9a7", null ],
    [ "onCreate", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#a40ba3d30a1e269837b8f892e8ea19d2a", null ],
    [ "onCreateEngine", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#ae1b396f91b74edc3a7922c7a3bc6773b", null ],
    [ "onDestroy", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#a53cb2e415472237a21367d9bcd8ba524", null ],
    [ "onLowMemory", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#a07fc9168b1b08449967c1c15d811d067", null ],
    [ "onRebind", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#ace58dc68079807d2bf87f0c9492deaaf", null ],
    [ "onStartCommand", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#ac47bc90a7d4631ed4baa76854783a605", null ],
    [ "onTaskRemoved", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#aaef102a1eeceb4fbe170cf59e8763445", null ],
    [ "onTrimMemory", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#aab384249ba60707838692e3a42c0a7ef", null ],
    [ "onUnbind", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html#ab0a60e8c5cdc85a3ff65765bb2b75cfb", null ]
];