var classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config =
[
    [ "LauncherActivityDisplayStyle", "d4/d3a/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_launcher_activity_display_style.html", "d4/d3a/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_launcher_activity_display_style" ],
    [ "PreviewSettingButtonBehaviour", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour" ],
    [ "LiveWallpaperConfig", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a474a072827230f905e03ba3636ef9bc9", null ],
    [ "LiveWallpaperConfig", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a79d6960fda4a63285f2bea58953d4df5", null ],
    [ "toString", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#aad46cf0a45172b4f2093f6815a68608e", null ],
    [ "androidBuildDate", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a0dc0e4d83b1ba5892aad78d71e738bbe", null ],
    [ "androidVersion", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a5e672c7f68070d089d7d2a35c6a66993", null ],
    [ "bypassInitialActivityCheck", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a83d949355ab41e3061eedc3fd3fd33d1", null ],
    [ "earlyTriggerScreenOff", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#af4b09eee80ab7721b3c89593f3341902", null ],
    [ "isIsolateMode", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a1747874c5cbf87d0e3e42b1514b6fc3d", null ],
    [ "isVerboseLogging", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a9a66c3ca0a197085daccf220b8ee68b1", null ],
    [ "launcherActivityClass", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a779ed6a6b0e380cadcbf6d37f6fddd8a", null ],
    [ "launcherActivityDisplayStyle", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a2d1baf2378ca66997aa919ef0c082426", null ],
    [ "parallelExecution", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#aafbca9e3be47cacab0a8d5ab1f67e286", null ],
    [ "previewSettingButtonBehaviour", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#af556ae9e43435d3bee62bff3948ecc30", null ],
    [ "screenSaverServiceClass", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a91d13366e2e87b9f02ec6234e406b744", null ],
    [ "surfaceUpdateInterval", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#af27a442fe7f3aeda1e09d916d5330633", null ],
    [ "unityVersion", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a5cee119d4c49ca1e2c9d7504ab416baa", null ],
    [ "wallpaperServiceClass", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#abb34700a48a7b1ac3b0233d66e8d5864", null ]
];