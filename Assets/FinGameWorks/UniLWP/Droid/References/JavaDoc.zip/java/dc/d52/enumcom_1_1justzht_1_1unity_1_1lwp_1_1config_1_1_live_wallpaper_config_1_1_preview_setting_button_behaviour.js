var enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour =
[
    [ "PreviewSettingButtonBehaviour", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#aa8827d56863314577f49eb4086643ab6", null ],
    [ "getValue", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a5c5a4db0ce97685a88f726690466d04e", null ],
    [ "valueOf", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a9925a9894abbecf9f5f98fed6d2d03a2", null ],
    [ "Both", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a191c24928368e558a9dfbe9b8807f617", null ],
    [ "NotifyUnity", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a2facdb2341f8e03978d2f26f41a6f8f8", null ],
    [ "StartLauncherActivity", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a021a4d7ee8df67d3027ca23a27cd8857", null ]
];