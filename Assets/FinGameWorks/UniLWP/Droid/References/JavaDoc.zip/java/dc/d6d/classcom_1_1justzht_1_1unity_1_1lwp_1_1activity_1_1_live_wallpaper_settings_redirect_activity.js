var classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_settings_redirect_activity =
[
    [ "onCreate", "dc/d6d/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_settings_redirect_activity.html#abe1b71c4b4edc5c75e65c61613e6ab62", null ]
];