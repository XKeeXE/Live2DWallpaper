var enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status =
[
    [ "ScreenStatus", "dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html#a4018854c22c4b93f9dc7b66f8e960773", null ],
    [ "getValue", "dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html#a78ba2f2521a18e79881cc489d1b60eb5", null ],
    [ "LockedAndAOD", "dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html#a200ebd2c94c158117bf697683ad638d9", null ],
    [ "LockedAndOff", "dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html#a91a3331ceceb47f72aeb257f00d85533", null ],
    [ "LockedAndOn", "dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html#a29586bfbe3e3ba3480190cb8d99f807c", null ],
    [ "Unlocked", "dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html#a344dc19ae841e91838b25da57473d438", null ]
];