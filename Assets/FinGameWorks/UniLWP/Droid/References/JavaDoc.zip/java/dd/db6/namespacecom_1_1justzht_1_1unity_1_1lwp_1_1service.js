var namespacecom_1_1justzht_1_1unity_1_1lwp_1_1service =
[
    [ "LiveWallpaperPresentationService", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service" ],
    [ "LiveWallpaperScreenSaverService", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service.html", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service" ]
];