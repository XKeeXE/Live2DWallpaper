var classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0 =
[
    [ "LiveWallpaperPresentationServiceEngine", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#ab7983ef7a9ca7649948b3b61305d4e2b", null ],
    [ "onApplyWindowInsets", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#ae00c4d3c6f3e673b1e80219b6d8d4842", null ],
    [ "onCommand", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#af2eba52eba7fcdb8f3ff2bfc73b86be9", null ],
    [ "onCreate", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#ab8519ea6eb4f6f1c6864b75d511b4bfb", null ],
    [ "onDesiredSizeChanged", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#a84350d8c10315bb9632472a41c46d184", null ],
    [ "onDestroy", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#a5805bbffaac7ffecb70c27f258071337", null ],
    [ "onOffsetsChanged", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#a7beed701ff0b136d7cd35d8883f04a99", null ],
    [ "onTouchEvent", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#ac02762cf26199c0a5ae9f39f33b48d51", null ],
    [ "onVisibilityChanged", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#a6e44f4b39c160b9851079aea436a5093", null ],
    [ "gestureDetector", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#afb3a6375a6ff119987354ddf5613bd79", null ],
    [ "stockBehavior", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#af1c3014250cb7f73891b1394b120e0b7", null ]
];