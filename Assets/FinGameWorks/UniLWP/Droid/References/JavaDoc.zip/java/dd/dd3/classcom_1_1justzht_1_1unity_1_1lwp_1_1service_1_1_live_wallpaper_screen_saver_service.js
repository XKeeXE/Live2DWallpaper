var classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service =
[
    [ "onAttachedToWindow", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service.html#a48848cc5bd1d61cb4fb6fc5afb10bc6a", null ],
    [ "onDetachedFromWindow", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service.html#a4c9774b279f06dddd1b5f6b86a553047", null ],
    [ "onDreamingStarted", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service.html#a454629c3adc5e7fb8d734071ac35cdbf", null ],
    [ "onDreamingStopped", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service.html#a14fb06b8a76e2be329d57968c2ba57c7", null ],
    [ "surfaceView", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service.html#a98da543426d3bd79c0a38927a402aade", null ]
];