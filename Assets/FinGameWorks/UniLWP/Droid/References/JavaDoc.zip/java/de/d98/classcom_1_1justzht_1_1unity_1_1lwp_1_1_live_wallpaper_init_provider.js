var classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider =
[
    [ "delete", "de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#a5048b1a538680a13f21da5c91113d538", null ],
    [ "getType", "de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#a6714759bb66a1cf1e2ac8313946d9abb", null ],
    [ "insert", "de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#adad3b40d744a52f3d5aade9592229fa0", null ],
    [ "onCreate", "de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#a4947baffdc1f8a9ef675482215cfc25a", null ],
    [ "query", "de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#afda8fd2aa8c8c550a17b2f659c90c215", null ],
    [ "update", "de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#a6ce6234c53166dfd25d5d5fc34fbf898", null ]
];