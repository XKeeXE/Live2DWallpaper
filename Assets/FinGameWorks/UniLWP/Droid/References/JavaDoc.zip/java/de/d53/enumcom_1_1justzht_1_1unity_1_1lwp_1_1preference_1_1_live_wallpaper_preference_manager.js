var enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager =
[
    [ "getInstance", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html#abbe64667e79be0b59665af77d0f1db4f", null ],
    [ "getPreferenceName", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html#a6535c081a9010c6b869b472acabe1351", null ],
    [ "reportChanged", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html#ad3d542aa674f346e6ba5d4603ae57b6e", null ],
    [ "setListener", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html#aa719d3690e9dfa4f248c6dff1d442db7", null ],
    [ "INSTANCE", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html#a10751df72cd8966727d679adaf8a1c85", null ]
];