var searchData=
[
  ['notifyunity_411',['NotifyUnity',['../dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a2facdb2341f8e03978d2f26f41a6f8f8',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig::PreviewSettingButtonBehaviour']]]
];
