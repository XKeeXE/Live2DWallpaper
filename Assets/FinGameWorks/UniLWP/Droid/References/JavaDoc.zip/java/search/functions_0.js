var searchData=
[
  ['activityvisibility_275',['activityVisibility',['../d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a7ebbf9089282ba30d75bdda67816e0f8',1,'com::justzht::unity::lwp::LiveWallpaperPresentationEventWrapper']]]
];
