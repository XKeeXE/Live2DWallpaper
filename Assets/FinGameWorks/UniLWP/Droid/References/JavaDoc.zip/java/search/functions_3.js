var searchData=
[
  ['enteractivityupdated_282',['EnterActivityUpdated',['../db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#a8652299d11786bf46270cbe2b779f885',1,'com::justzht::unity::lwp::LiveWallpaperListener']]]
];
