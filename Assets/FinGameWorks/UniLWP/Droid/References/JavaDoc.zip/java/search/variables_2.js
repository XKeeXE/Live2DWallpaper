var searchData=
[
  ['darkmode_393',['darkMode',['../dd/db9/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager.html#a552c77a3bd5757a966684fda7216491b',1,'com::justzht::unity::lwp::LiveWallpaperListenerManager']]]
];
