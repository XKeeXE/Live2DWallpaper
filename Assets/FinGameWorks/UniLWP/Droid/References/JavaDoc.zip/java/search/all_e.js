var searchData=
[
  ['readme_2emd_163',['README.md',['../d9/dd6/_r_e_a_d_m_e_8md.html',1,'']]],
  ['removepreviouswallpaper_164',['removePreviousWallpaper',['../d0/deb/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_manager.html#a5d6a91b9b6845bc7b89d8b6ee5b9396d',1,'com::justzht::unity::lwp::LiveWallpaperManager']]],
  ['reportchanged_165',['reportChanged',['../de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html#ad3d542aa674f346e6ba5d4603ae57b6e',1,'com::justzht::unity::lwp::preference::LiveWallpaperPreferenceManager']]],
  ['resumeunity_166',['resumeUnity',['../d0/deb/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_manager.html#a65d17909df5a0f887a02327e441d7d9f',1,'com::justzht::unity::lwp::LiveWallpaperManager']]],
  ['run_167',['run',['../d1/deb/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_execution_thread.html#a2c3c4ebb1178a257af19b628a5ada39d',1,'com::justzht::unity::lwp::LiveWallpaperExecutionThread']]]
];
