var searchData=
[
  ['xoffset_208',['xOffset',['../dd/db9/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager.html#a4702491059a040524f6b3112185b6201',1,'com::justzht::unity::lwp::LiveWallpaperListenerManager']]],
  ['xoffsetstep_209',['xOffsetStep',['../dd/db9/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager.html#a5107a40d22fbee005f38a5f07c8ae47a',1,'com::justzht::unity::lwp::LiveWallpaperListenerManager']]]
];
