var searchData=
[
  ['wallpaperoffsetsupdated_205',['WallpaperOffsetsUpdated',['../db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#aeed0f7fcdda5a0f5d935b8cc2408e743',1,'com::justzht::unity::lwp::LiveWallpaperListener']]],
  ['wallpaperserviceclass_206',['wallpaperServiceClass',['../d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#abb34700a48a7b1ac3b0233d66e8d5864',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig']]],
  ['windowinsets_207',['windowInsets',['../d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#ab3010cf1cc8426bb2429fd2ede27c34f',1,'com.justzht.unity.lwp.LiveWallpaperPresentationEventWrapper.windowInsets(WindowInsets insets)'],['../d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a02dda0f7da06b6ad74271900f297ef43',1,'com.justzht.unity.lwp.LiveWallpaperPresentationEventWrapper.windowInsets(int left, int top, int right, int bottom)']]]
];
