var searchData=
[
  ['valueof_386',['valueOf',['../d4/d3a/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_launcher_activity_display_style.html#a69a394c7afdacb099ed2015627ab2bc2',1,'com.justzht.unity.lwp.config.LiveWallpaperConfig.LauncherActivityDisplayStyle.valueOf()'],['../dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a9925a9894abbecf9f5f98fed6d2d03a2',1,'com.justzht.unity.lwp.config.LiveWallpaperConfig.PreviewSettingButtonBehaviour.valueOf()']]]
];
