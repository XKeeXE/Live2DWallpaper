var searchData=
[
  ['parallelexecution_412',['parallelExecution',['../d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#aafbca9e3be47cacab0a8d5ab1f67e286',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig']]],
  ['preference_413',['Preference',['../d4/d3a/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_launcher_activity_display_style.html#a1c53fb5a784644029d6e794dcb844efa',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig::LauncherActivityDisplayStyle']]],
  ['previewsettingbuttonbehaviour_414',['previewSettingButtonBehaviour',['../d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#af556ae9e43435d3bee62bff3948ecc30',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig']]]
];
