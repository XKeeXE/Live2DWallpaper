var searchData=
[
  ['gesturedetector_395',['gestureDetector',['../dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html#afb3a6375a6ff119987354ddf5613bd79',1,'com::justzht::unity::lwp::service::LiveWallpaperPresentationService::LiveWallpaperPresentationServiceEngine']]]
];
