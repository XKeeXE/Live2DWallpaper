var searchData=
[
  ['both_3',['Both',['../dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html#a191c24928368e558a9dfbe9b8807f617',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig::PreviewSettingButtonBehaviour']]],
  ['bypassinitialactivitycheck_4',['bypassInitialActivityCheck',['../d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a83d949355ab41e3061eedc3fd3fd33d1',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig']]]
];
