var searchData=
[
  ['unloadunity_384',['UnloadUnity',['../d0/deb/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_manager.html#a37ae54357cd0bde47e92bfb65a4c4d8a',1,'com::justzht::unity::lwp::LiveWallpaperManager']]],
  ['update_385',['update',['../de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#a6ce6234c53166dfd25d5d5fc34fbf898',1,'com::justzht::unity::lwp::LiveWallpaperInitProvider']]]
];
