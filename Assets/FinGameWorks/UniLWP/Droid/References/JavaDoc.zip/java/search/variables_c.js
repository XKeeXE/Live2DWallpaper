var searchData=
[
  ['wallpaperserviceclass_430',['wallpaperServiceClass',['../d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#abb34700a48a7b1ac3b0233d66e8d5864',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig']]]
];
