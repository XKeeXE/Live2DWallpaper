var searchData=
[
  ['darkmodeenableupdated_278',['DarkModeEnableUpdated',['../db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html#a3ad03e69bc6f59c72bd32c3a42f7c280',1,'com::justzht::unity::lwp::LiveWallpaperListener']]],
  ['deinit_279',['DeInit',['../d0/deb/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_manager.html#a9d8ebaaf119c3110f94a29a0bdec3e7d',1,'com::justzht::unity::lwp::LiveWallpaperManager']]],
  ['delete_280',['delete',['../de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html#a5048b1a538680a13f21da5c91113d538',1,'com::justzht::unity::lwp::LiveWallpaperInitProvider']]],
  ['disconnectunitydisplay_281',['disconnectUnityDisplay',['../d0/deb/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_manager.html#a0bcf6c418f369660683e5468457f0856',1,'com::justzht::unity::lwp::LiveWallpaperManager']]]
];
