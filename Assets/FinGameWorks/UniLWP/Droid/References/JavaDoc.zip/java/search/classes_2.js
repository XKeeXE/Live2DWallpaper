var searchData=
[
  ['screenstatus_240',['ScreenStatus',['../dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html',1,'com::justzht::unity::lwp::LiveWallpaperListenerManager']]],
  ['settingsfragment_241',['SettingsFragment',['../da/dd4/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_preference_activity_1_1_settings_fragment.html',1,'com::justzht::unity::lwp::activity::LiveWallpaperPreferenceActivity']]]
];
