var searchData=
[
  ['configurationchanged_276',['configurationChanged',['../d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a20cc23a7262394eb96fe47f37e860786',1,'com::justzht::unity::lwp::LiveWallpaperPresentationEventWrapper']]],
  ['connectunitydisplay_277',['connectUnityDisplay',['../d0/deb/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_manager.html#a17ba598c7082f81e4613a5a6a1b89eb9',1,'com::justzht::unity::lwp::LiveWallpaperManager']]]
];
