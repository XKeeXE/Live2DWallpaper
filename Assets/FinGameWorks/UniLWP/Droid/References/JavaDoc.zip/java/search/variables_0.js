var searchData=
[
  ['androidbuilddate_389',['androidBuildDate',['../d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a0dc0e4d83b1ba5892aad78d71e738bbe',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig']]],
  ['androidversion_390',['androidVersion',['../d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html#a5e672c7f68070d089d7d2a35c6a66993',1,'com::justzht::unity::lwp::config::LiveWallpaperConfig']]]
];
