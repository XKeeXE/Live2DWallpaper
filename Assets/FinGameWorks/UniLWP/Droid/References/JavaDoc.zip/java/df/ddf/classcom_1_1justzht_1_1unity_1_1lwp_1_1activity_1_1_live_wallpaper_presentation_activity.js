var classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity =
[
    [ "onAttachedToWindow", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a3e6acc2d96ba9793a99ef33167c09acc", null ],
    [ "onConfigurationChanged", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a60aba6137058bb5d1361f980b125fded", null ],
    [ "onCreate", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#afed1c33bf273bce1d9ff1e998799ce52", null ],
    [ "onDestroy", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a2234a15c639d962d9301b3ee7fa81ec8", null ],
    [ "onKeyDown", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a4cba238bef09d54d4e746aca8d28952e", null ],
    [ "onLowMemory", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#affd437c298053d4199d9c8241edd3f8d", null ],
    [ "onNewIntent", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#afe4616beadd067f9775c2263899bc100", null ],
    [ "onPause", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#aa1f20bed95e26ebe74de76ba73409b68", null ],
    [ "onResume", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#ac4a420c2a210bad057259cda6d9d4a77", null ],
    [ "onStart", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a78c41915c7f7242c641c6c683328fd25", null ],
    [ "onTouchEvent", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a4867debb74f9329fa48919f45635b3ad", null ],
    [ "onTrimMemory", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a6a038904b09c914416519a2477b39b3c", null ],
    [ "onWindowFocusChanged", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a40c2fdd85836b2b2da3542bc9a467ac1", null ],
    [ "surfaceView", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html#a4773f1d4ca5fde23cace3384ecf134a5", null ]
];