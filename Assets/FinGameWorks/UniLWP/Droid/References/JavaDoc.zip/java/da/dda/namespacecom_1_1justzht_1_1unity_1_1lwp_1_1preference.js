var namespacecom_1_1justzht_1_1unity_1_1lwp_1_1preference =
[
    [ "LiveWallpaperPreferenceListener", "d7/d7c/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener.html", "d7/d7c/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener" ],
    [ "LiveWallpaperPreferenceManager", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager" ],
    [ "PreferenceUtils", "db/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_preference_utils.html", "db/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_preference_utils" ]
];