var hierarchy =
[
    [ "Engine", null, [
      [ "com.justzht.unity.lwp.service.LiveWallpaperPresentationService.LiveWallpaperPresentationServiceEngine", "dd/dbe/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service_1_1_live_51aff0901c464627ea4a251245ba3ea0.html", null ]
    ] ],
    [ "com.justzht.unity.lwp.config.LiveWallpaperConfig.LauncherActivityDisplayStyle", "d4/d3a/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_launcher_activity_display_style.html", null ],
    [ "com.justzht.unity.lwp.config.LiveWallpaperConfig", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html", null ],
    [ "com.justzht.unity.lwp.config.LiveWallpaperConfigManager", "d3/d9c/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_manager.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperDefine", "d4/d03/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_define.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperListener", "db/de4/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperListenerManager", "dd/db9/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperLogManager.LiveWallpaperLogInterface", "d6/de8/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperLogManager", "db/d2b/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager.html", null ],
    [ "com.justzht.unity.lwp.preference.LiveWallpaperPreferenceListener", "d7/d7c/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_listener.html", null ],
    [ "com.justzht.unity.lwp.preference.LiveWallpaperPreferenceManager", "de/d53/enumcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_live_wallpaper_preference_manager.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperPresentationEventWrapper", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperUtils", "d6/d55/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_utils.html", null ],
    [ "com.justzht.unity.lwp.preference.PreferenceUtils", "db/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1preference_1_1_preference_utils.html", null ],
    [ "com.justzht.unity.lwp.config.LiveWallpaperConfig.PreviewSettingButtonBehaviour", "dc/d52/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_1_1_preview_setting_button_behaviour.html", null ],
    [ "com.justzht.unity.lwp.LiveWallpaperListenerManager.ScreenStatus", "dd/d92/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_listener_manager_1_1_screen_status.html", null ],
    [ "Thread", null, [
      [ "com.justzht.unity.lwp.LiveWallpaperExecutionThread", "d1/deb/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_execution_thread.html", null ]
    ] ],
    [ "Activity", null, [
      [ "com.justzht.unity.lwp.activity.LiveWallpaperLauncherRedirectActivity", "d8/df8/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_launcher_redirect_activity.html", null ],
      [ "com.justzht.unity.lwp.activity.LiveWallpaperPresentationActivity", "df/ddf/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_presentation_activity.html", null ],
      [ "com.justzht.unity.lwp.activity.LiveWallpaperSettingsRedirectActivity", "dc/d6d/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_settings_redirect_activity.html", null ],
      [ "com.justzht.unity.lwp.activity.LiveWallpaperUnityCheckBypassActivity", "d9/d0a/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_unity_check_bypass_activity.html", null ]
    ] ],
    [ "AppCompatActivity", null, [
      [ "com.justzht.unity.lwp.activity.LiveWallpaperPreferenceActivity", "d6/d00/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_preference_activity.html", null ]
    ] ],
    [ "BroadcastReceiver", null, [
      [ "com.justzht.unity.lwp.LiveWallpaperScreenBroadcastReceiver", "d1/df5/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_screen_broadcast_receiver.html", null ]
    ] ],
    [ "ContentProvider", null, [
      [ "com.justzht.unity.lwp.LiveWallpaperInitProvider", "de/d98/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_init_provider.html", null ]
    ] ],
    [ "DreamService", null, [
      [ "com.justzht.unity.lwp.service.LiveWallpaperScreenSaverService", "dd/dd3/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_screen_saver_service.html", null ]
    ] ],
    [ "IUnityPlayerLifecycleEvents", null, [
      [ "com.justzht.unity.lwp.LiveWallpaperManager", "d0/deb/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_manager.html", null ]
    ] ],
    [ "PreferenceFragmentCompat", null, [
      [ "com.justzht.unity.lwp.activity.LiveWallpaperPreferenceActivity.SettingsFragment", "da/dd4/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_preference_activity_1_1_settings_fragment.html", null ]
    ] ],
    [ "ThreadFactory", null, [
      [ "com.justzht.unity.lwp.LiveWallpaperExecutionThreadFactory", "d2/d52/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_execution_thread_factory.html", null ]
    ] ],
    [ "UnityPlayer", null, [
      [ "com.justzht.unity.lwp.LiveWallpaperPlayer", "d6/d12/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_player.html", null ]
    ] ],
    [ "WallpaperService", null, [
      [ "com.justzht.unity.lwp.service.LiveWallpaperPresentationService", "d0/dff/classcom_1_1justzht_1_1unity_1_1lwp_1_1service_1_1_live_wallpaper_presentation_service.html", null ]
    ] ]
];