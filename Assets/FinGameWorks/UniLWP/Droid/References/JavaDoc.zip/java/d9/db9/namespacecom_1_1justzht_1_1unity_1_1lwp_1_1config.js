var namespacecom_1_1justzht_1_1unity_1_1lwp_1_1config =
[
    [ "LiveWallpaperConfig", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config.html", "d3/de2/classcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config" ],
    [ "LiveWallpaperConfigManager", "d3/d9c/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_manager.html", "d3/d9c/enumcom_1_1justzht_1_1unity_1_1lwp_1_1config_1_1_live_wallpaper_config_manager" ]
];