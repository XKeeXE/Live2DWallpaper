var classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_screen_broadcast_receiver =
[
    [ "getStatus", "d1/df5/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_screen_broadcast_receiver.html#ab526feb65240554c518384492504e60f", null ],
    [ "onReceive", "d1/df5/classcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_screen_broadcast_receiver.html#a8d3a16e087b24ab1fcb89a6a2ed7f5a4", null ]
];