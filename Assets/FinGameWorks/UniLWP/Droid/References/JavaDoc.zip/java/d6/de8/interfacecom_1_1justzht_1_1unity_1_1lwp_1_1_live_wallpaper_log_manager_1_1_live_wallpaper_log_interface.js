var interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface =
[
    [ "logD", "d6/de8/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface.html#a78d8b6835739cfcfc9604a7419026f57", null ],
    [ "logE", "d6/de8/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface.html#acfbf7beb03a29f7cce0443b083aed9a4", null ],
    [ "logI", "d6/de8/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface.html#ae3b13f9c5d55339f26f143c589bdd4c0", null ],
    [ "logW", "d6/de8/interfacecom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_log_manager_1_1_live_wallpaper_log_interface.html#ad05f548da67e6a045a7b3425b0c4d713", null ]
];