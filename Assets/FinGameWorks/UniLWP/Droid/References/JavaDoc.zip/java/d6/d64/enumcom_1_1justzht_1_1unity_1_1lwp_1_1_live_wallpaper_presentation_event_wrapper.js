var enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper =
[
    [ "activityVisibility", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a7ebbf9089282ba30d75bdda67816e0f8", null ],
    [ "configurationChanged", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a20cc23a7262394eb96fe47f37e860786", null ],
    [ "getInstance", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a257b25351b679c176a0b2224db5b46f8", null ],
    [ "intent", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#aabac8c0026741ebc09cc1db3f087eb19", null ],
    [ "offsets", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a4dbb3df8afec4841c3b30d4a5725485e", null ],
    [ "onLowMemory", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a3a35e3665682b4c4c4042d0ff2b1e5b3", null ],
    [ "serviceIsInPreview", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#ab6e99bfe344e9c69cfa8af652cea6f0f", null ],
    [ "serviceVisibility", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a8e65c6f652d34e948dac0348144a06fb", null ],
    [ "setupSurfaceHolderInWallpaperServiceOnCreate", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a2a77fdc03416c7cd9a375d833f13dc05", null ],
    [ "setupSurfaceHolderInWallpaperServiceOnDestroy", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#aeed3cc8459386423175d88c643199642", null ],
    [ "setupSurfaceViewInActivityOnCreate", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a06b3136f3b646794f03a7e0c9f8f7478", null ],
    [ "setupSurfaceViewInActivityOnDestroy", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#aafc2e069325da4e5b3e70e4dc48c1288", null ],
    [ "setupSurfaceViewInDayDreamServiceOnAttachedToWindow", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#abfceb4a9e29c749536e0813a89b08833", null ],
    [ "setupSurfaceViewInDayDreamServiceOnDetachedFromWindow", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#ae2a1b830d697cd3b20c2721b98667754", null ],
    [ "touchEvent", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a155ca27cce5a42708c977cfa33822963", null ],
    [ "windowInsets", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a02dda0f7da06b6ad74271900f297ef43", null ],
    [ "windowInsets", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#ab3010cf1cc8426bb2429fd2ede27c34f", null ],
    [ "INSTANCE", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a87413fccf0d6d7ccb26ef4cf02a478d6", null ],
    [ "surfaceHolderCallback", "d6/d64/enumcom_1_1justzht_1_1unity_1_1lwp_1_1_live_wallpaper_presentation_event_wrapper.html#a7cf38492fa6b6b6b1328f665150eba01", null ]
];