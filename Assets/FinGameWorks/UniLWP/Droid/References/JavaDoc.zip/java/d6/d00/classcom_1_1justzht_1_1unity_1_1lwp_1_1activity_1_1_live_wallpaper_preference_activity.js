var classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_preference_activity =
[
    [ "SettingsFragment", "da/dd4/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_preference_activity_1_1_settings_fragment.html", "da/dd4/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_preference_activity_1_1_settings_fragment" ],
    [ "onCreate", "d6/d00/classcom_1_1justzht_1_1unity_1_1lwp_1_1activity_1_1_live_wallpaper_preference_activity.html#a154a8985cdf3bd39eab30ead6333b71b", null ]
];