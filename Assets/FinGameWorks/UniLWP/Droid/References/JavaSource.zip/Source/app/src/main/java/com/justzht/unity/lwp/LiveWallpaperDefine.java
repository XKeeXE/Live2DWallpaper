package com.justzht.unity.lwp;

class LiveWallpaperDefine {
    static String Tag = "UniLWP.Lib";
}
