package com.justzht.unity.lwp.config;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.dreams.DreamService;
import android.service.wallpaper.WallpaperService;

import com.justzht.unity.lwp.LiveWallpaperUtils;
import com.justzht.unity.lwp.activity.LiveWallpaperLauncherRedirectActivity;
import com.justzht.unity.lwp.service.LiveWallpaperScreenSaverService;
import com.justzht.unity.lwp.service.LiveWallpaperPresentationService;

/**
 * Data class to store configurations
 */
public class LiveWallpaperConfig
{
    /**
     * Enable this to log UniLWP related entries
     */
    public boolean isVerboseLogging = true;
    /**
     * Enable this to only init UniLWP without actually init Unity
     */
    public boolean isIsolateMode = false;
    /**
     * Certain Unity Plugins check UnityPlayer.currentActivity before running, toggle this to init a blank activity as soon as possible (and then supply a real activity)
     */
    public boolean bypassInitialActivityCheck = false;
    public boolean earlyTriggerScreenOff = true;
    public long surfaceUpdateInterval = 0;

    public String androidVersion = "";
    public String androidBuildDate = "";
    public String unityVersion = "";

    public enum LauncherActivityDisplayStyle
    {
        /**
         * Unity stock style, meaning just a full-screen activity which hides navi bar and status bar
         */
        UnityFullscreen(0),
        UnityStable(1),
        /**
         * Preference style
         */
        Preference(2);

        private final int value;
        public int getValue() { return value; }
        LauncherActivityDisplayStyle(int value) { this.value = value; }
        public static LauncherActivityDisplayStyle valueOf(int value)
        {
            switch (value)
            {
                default:
                case 0: return UnityFullscreen;
                case 1: return UnityStable;
                case 2: return Preference;
            }
        }
    }
    public LauncherActivityDisplayStyle launcherActivityDisplayStyle = LauncherActivityDisplayStyle.UnityFullscreen;

    public enum PreviewSettingButtonBehaviour
    {
        StartLauncherActivity(0),
        NotifyUnity(1),
        Both(2);

        private final int value;
        public int getValue() { return value; }
        PreviewSettingButtonBehaviour(int value) { this.value = value; }
        public static PreviewSettingButtonBehaviour valueOf(int value)
        {
            switch (value)
            {
                default:
                case 0: return StartLauncherActivity;
                case 1: return NotifyUnity;
                case 2: return Both;
            }
        }
    }
    public PreviewSettingButtonBehaviour previewSettingButtonBehaviour = PreviewSettingButtonBehaviour.NotifyUnity;

    public Class<? extends Activity> launcherActivityClass = LiveWallpaperLauncherRedirectActivity.class;
    public Class<? extends WallpaperService> wallpaperServiceClass = LiveWallpaperPresentationService.class;
    public Class<? extends DreamService> screenSaverServiceClass = LiveWallpaperScreenSaverService.class;


    /**
     * Init with default values
     */
    public LiveWallpaperConfig() {
    }

    /**
     * Init from xml values
     * @param context
     */
    public LiveWallpaperConfig(Context context)
    {
        PackageManager packageManager = context.getPackageManager();
        Bundle metaData = null;
        try {
            metaData = packageManager.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA).metaData;
        } catch (Exception e) {
            e.printStackTrace();
            LiveWallpaperUtils.logE(e.toString());
        }
        if (metaData != null)
        {
            isVerboseLogging = metaData.getBoolean("unilwp.logging.verbose",true);
            isIsolateMode = metaData.getBoolean("unilwp.behavior.isolate",false);
            surfaceUpdateInterval = metaData.getInt("unilwp.behavior.surface.updateRate",0);

            launcherActivityDisplayStyle = LauncherActivityDisplayStyle.valueOf(metaData.getInt("unilwp.style.activity.launch.display",0));
            previewSettingButtonBehaviour = PreviewSettingButtonBehaviour.valueOf(metaData.getInt("unilwp.behavior.preview.button.settings",0));

            earlyTriggerScreenOff = metaData.getBoolean("unilwp.behavior.screen.off.early",false);
            bypassInitialActivityCheck = metaData.getBoolean("unilwp.behavior.activity.bypass.initial",false);

            androidVersion = metaData.getString("unilwp.version.android","0.0.0");
            androidBuildDate = metaData.getString("unilwp.info.android.build.date","N/A");
            unityVersion = metaData.getString("unilwp.version.unity","0.0.0");
            String dayDreamClassStr = metaData.getString("unilwp.ref.class.screensaver.service", LiveWallpaperScreenSaverService.class.getName());
            if (!dayDreamClassStr.isEmpty())
            {
                try {
                    screenSaverServiceClass = (Class<? extends DreamService>) Class.forName(dayDreamClassStr);
                } catch (ClassNotFoundException e) {
                    LiveWallpaperUtils.logE("Cannot find daydream class");
                    LiveWallpaperUtils.logE(e.toString());
                    e.printStackTrace();
                }
            }

            String activityClassStr = metaData.getString("unilwp.ref.class.launcher.activity", LiveWallpaperLauncherRedirectActivity.class.getName());
            if (!activityClassStr.isEmpty())
            {
                try {
                    launcherActivityClass = (Class<? extends Activity>) Class.forName(activityClassStr);
                } catch (ClassNotFoundException e) {
                    LiveWallpaperUtils.logE("Cannot find activity class");
                    LiveWallpaperUtils.logE(e.toString());
                    e.printStackTrace();
                }
            }

            String wallpaperServiceClassStr = metaData.getString("unilwp.ref.class.wallpaper.service", LiveWallpaperPresentationService.class.getName());
            if (!wallpaperServiceClassStr.isEmpty())
            {
                try {
                    wallpaperServiceClass = (Class<? extends WallpaperService>) Class.forName(wallpaperServiceClassStr);
                } catch (ClassNotFoundException e) {
                    LiveWallpaperUtils.logE("Cannot find wallpaper service class");
                    LiveWallpaperUtils.logE(e.toString());
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public String toString() {
        return "LiveWallpaperConfig {" +
                "\n\tandroidBuildDate=" + androidBuildDate +
                "\n\tandroidVersion=" + androidVersion +
                "\n\tunityVersion=" + unityVersion +
                "\n\tisVerboseLogging=" + isVerboseLogging +
                "\n\tisIsolateMode=" + isIsolateMode +
                "\n\tbypassInitialActivityCheck=" + bypassInitialActivityCheck +
                "\n\tearlyTriggerScreenOff=" + earlyTriggerScreenOff +
                "\n\tsurfaceUpdateInterval=" + surfaceUpdateInterval +
                "\n\tlauncherActivityDisplayStyle=" + launcherActivityDisplayStyle +
                "\n\tpreviewSettingButtonBehaviour=" + previewSettingButtonBehaviour +
                "\n\tlauncherActivityClass=" + launcherActivityClass +
                "\n\twallpaperServiceClass=" + wallpaperServiceClass +
                "\n\tscreenSaverServiceClass=" + screenSaverServiceClass +
                "\n}";
    }

}
