package com.justzht.unity.lwp;

import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;


public class LiveWallpaperUtils
{
    public static Method getMethod(Object currentObject, String methodName) throws NoSuchMethodException, IllegalArgumentException {
        Class<?> currentClass = currentObject.getClass();
        Method method = null;
        while (currentClass != null && method == null) {
            try {
                method = currentClass.getDeclaredMethod(methodName);
            } catch (NoSuchMethodException e) {
                // method not present - try super class
                currentClass = currentClass.getSuperclass();
            }
        }
        if (method != null) {
            if (!method.isAccessible())
            {
                method.setAccessible(true);
            }
            return method;
        } else {
            throw new NoSuchMethodException();
        }
    }

    public static Field getField(Object currentObject, String fieldName) throws IllegalArgumentException, NoSuchFieldException {
        Class<?> currentClass = currentObject.getClass();
        Field field = null;
        while (currentClass != null && field == null) {
            try {
                field = currentClass.getDeclaredField(fieldName);
            } catch (NoSuchFieldException e) {
                currentClass = currentClass.getSuperclass();
            }
        }
        if (field != null) {
            if (!field.isAccessible())
            {
                field.setAccessible(true);
            }
            return field;
        } else {
            throw new NoSuchFieldException();
        }
    }

    public static void logD(String msg)
    {
        if (LiveWallpaperManager.getInstance().liveWallpaperConfig == null || LiveWallpaperManager.getInstance().liveWallpaperConfig.isVerboseLogging)
        {
            if (Thread.currentThread().getStackTrace().length > 3) {
                String fullClassName = Thread.currentThread().getStackTrace()[3].getClassName();
                String className = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
                String methodName = Thread.currentThread().getStackTrace()[3].getMethodName();
                int lineNumber = Thread.currentThread().getStackTrace()[3].getLineNumber();
                Log.d(LiveWallpaperDefine.Tag, className + "." + methodName + " (line " + lineNumber + ") --> " + msg);
            }else
            {
                Log.d(LiveWallpaperDefine.Tag,msg);
            }
        }
        if (LiveWallpaperLogManager.getInstance().hasExternalLogger()) { LiveWallpaperLogManager.getInstance().getLogInterface().logD(msg); }
    }

    public static void logW(String msg)
    {
        if (LiveWallpaperManager.getInstance().liveWallpaperConfig == null || LiveWallpaperManager.getInstance().liveWallpaperConfig.isVerboseLogging)
        {
            if (Thread.currentThread().getStackTrace().length > 3) {
                String fullClassName = Thread.currentThread().getStackTrace()[3].getClassName();
                String className = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
                String methodName = Thread.currentThread().getStackTrace()[3].getMethodName();
                int lineNumber = Thread.currentThread().getStackTrace()[3].getLineNumber();
                Log.w(LiveWallpaperDefine.Tag, className + "." + methodName + " (line " + lineNumber + ") --> " + msg);
            }else
            {
                Log.w(LiveWallpaperDefine.Tag,msg);
            }
        }
        if (LiveWallpaperLogManager.getInstance().hasExternalLogger()) { LiveWallpaperLogManager.getInstance().getLogInterface().logD(msg); }
    }

    public static void logE(String msg)
    {
        if (LiveWallpaperManager.getInstance().liveWallpaperConfig == null || LiveWallpaperManager.getInstance().liveWallpaperConfig.isVerboseLogging)
        {
            if (Thread.currentThread().getStackTrace().length > 3)
            {
                String fullClassName = Thread.currentThread().getStackTrace()[3].getClassName();
                String className = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
                String methodName = Thread.currentThread().getStackTrace()[3].getMethodName();
                int lineNumber = Thread.currentThread().getStackTrace()[3].getLineNumber();
                Log.e(LiveWallpaperDefine.Tag, className + "." + methodName + " (line " + lineNumber + ") --> " + msg);
            }else
            {
                Log.e(LiveWallpaperDefine.Tag,msg);
            }
        }
        if (LiveWallpaperLogManager.getInstance().hasExternalLogger()) { LiveWallpaperLogManager.getInstance().getLogInterface().logE(msg); }
    }
}
