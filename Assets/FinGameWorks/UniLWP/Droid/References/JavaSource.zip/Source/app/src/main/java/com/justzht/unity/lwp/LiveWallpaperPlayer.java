package com.justzht.unity.lwp;

import android.annotation.SuppressLint;
import android.content.Context;
import com.unity3d.player.IUnityPlayerLifecycleEvents;
import com.unity3d.player.OrientationLockListener;
import com.unity3d.player.UnityPlayer;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.stream.Stream;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;
import static com.justzht.unity.lwp.LiveWallpaperUtils.logE;

@SuppressLint("ViewConstructor")
public class LiveWallpaperPlayer extends UnityPlayer {
    public LiveWallpaperPlayer(Context context, IUnityPlayerLifecycleEvents iUnityPlayerLifecycleEvents) {
        super(context, iUnityPlayerLifecycleEvents);
        logD("LiveWallpaperPlayer created");
    }

    public void listAllFields()
    {
        logD("LiveWallpaperPlayer listAllFields");
        Class<?> unityPlayerClass = LiveWallpaperPlayer.this.getClass().getSuperclass();
        if (unityPlayerClass != null)
        {
            Stream.of(unityPlayerClass.getDeclaredFields()).forEach(field -> {
                logD("LiveWallpaperPlayer field " + field.getName() + " (" + field.getType() + ")");
            });
        }
    }

    public Context checkMContext() {
        logD("LiveWallpaperPlayer check mContext");
        Field f;
        try {
            f = Objects.requireNonNull(this.getClass().getSuperclass()).getDeclaredField("mContext");
            f.setAccessible(true);
            Context mContext = (Context) f.get(this);
            logD("LiveWallpaperPlayer mContext = " + mContext);
            return mContext;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            logE("mContext check failed" + "\n" + e);
        }
        return null;
    }

    public OrientationLockListener getOrCreateOrientationLockListener() {
        try {
            Context context = LiveWallpaperManager.getInstance().getContext();
            Field f = Objects.requireNonNull(this.getClass().getSuperclass()).getDeclaredField("m_OrientationLockListener");
            f.setAccessible(true);
            OrientationLockListener listener = (OrientationLockListener) f.get(this);
            if (listener == null) {
                listener = OrientationLockListener.class.getDeclaredConstructor(Context.class).newInstance(context);
                f.set(this, listener);
            }
            return listener;
        } catch (NoSuchFieldException | IllegalAccessException | InvocationTargetException | InstantiationException | NoSuchMethodException e) {
            logE("LiveWallpaperPlayer getOrCreateOrientationLockListener failed" + "\n" + e);
            e.printStackTrace();
        }
        return null;
    }

    public void callPrivateSendSurfaceChangedEvent() {
        try {
            Method method = this.getClass().getSuperclass().getDeclaredMethod("sendSurfaceChangedEvent");
            method.setAccessible(true);
            method.invoke(this);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            logE("LiveWallpaperPlayer callPrivateSendSurfaceChangedEvent failed" + "\n" + e);
            e.printStackTrace();
        }
    }

    @Override
    public void resume() {
        logD("LiveWallpaperPlayer resume");

        // to counter the mActivity check for m_OrientationLockListener
        try {
            OrientationLockListener listener = getOrCreateOrientationLockListener();
            logD("LiveWallpaperPlayer OrientationLockListener " + listener);
        } catch (Exception e) {
            logE("LiveWallpaperPlayer getOrCreateOrientationLockListener failed" + "\n" + e);
            e.printStackTrace();
        }
        super.resume();
    }

    @Override
    protected boolean isUaaLUseCase() {
        return true;
    }

    @Override
    protected void showSoftInput(String s, int i, boolean b, boolean b1, boolean b2, boolean b3, String s1, int i1, boolean b4, boolean b5) {
        if (currentActivity != null) {
            super.showSoftInput(s, i, b, b1, b2, b3, s1, i1, b4, b5);
        } else {
            logE("showSoftInput with null currentActivity, do nothing");
        }
    }

    @Override
    protected void executeGLThreadJobs() {
        super.executeGLThreadJobs();
    }
}
