package com.justzht.unity.lwp.preference;

import android.content.Context;
import android.content.SharedPreferences;

import com.justzht.unity.lwp.LiveWallpaperManager;

import java.util.Map;

public enum LiveWallpaperPreferenceManager
{
    INSTANCE;

    public static LiveWallpaperPreferenceManager getInstance()
    {
        return INSTANCE;
    }

    private LiveWallpaperPreferenceListener preferenceListener;


    public String getPreferenceName()
    {
        Context context = LiveWallpaperManager.getInstance().getContext();
        return context.getPackageName();
    }

    public void setListener(LiveWallpaperPreferenceListener listener)
    {
        preferenceListener = listener;
        Context context = LiveWallpaperManager.getInstance().getContext();
        SharedPreferences sharedPreferences = context.getSharedPreferences(getPreferenceName(), Context.MODE_PRIVATE);
        sharedPreferences.registerOnSharedPreferenceChangeListener(this::reportChanged);

        // send all key values
        Map<String, ?> all = sharedPreferences.getAll();
        all.keySet().forEach(key -> {
            reportChanged(sharedPreferences, key);
        });
    }

    public void reportChanged(SharedPreferences sharedPreferences, String key)
    {
        if (preferenceListener == null) { return; }
        Object value = sharedPreferences.getAll().get(key);
        if (value instanceof String)
        {
            preferenceListener.PreferenceUpdated(key, (String) value);
        }
        else if (value instanceof Boolean)
        {
            preferenceListener.PreferenceUpdated(key, (Boolean) value);
        }else if (value instanceof Float)
        {
            preferenceListener.PreferenceUpdated(key, (Float) value);
        }else if (value instanceof Integer)
        {
            preferenceListener.PreferenceUpdated(key, (Integer) value);
        }
    }
}
