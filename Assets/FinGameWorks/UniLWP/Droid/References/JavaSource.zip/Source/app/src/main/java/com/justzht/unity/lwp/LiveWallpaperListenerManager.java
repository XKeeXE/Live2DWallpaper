package com.justzht.unity.lwp;

/**
 * Provide global access for the LiveWallpaperListener event listener
 */
public enum LiveWallpaperListenerManager {
    INSTANCE();
    public static LiveWallpaperListenerManager getInstance() {
        return INSTANCE;
    }

    protected void setEventListener(LiveWallpaperListener eventListener) {
        this.eventListener = eventListener;

        // report any thing we know now
        LiveWallpaperUtils.logD("LiveWallpaperListenerManager.setEventListener finished, now report every device state known");
        NotifyScreenDisplayStatusUpdated(LiveWallpaperScreenBroadcastReceiver.getStatus());
        NotifyServiceIsInPreviewUpdated();
        NotifyDarkModeEnableUpdated();
        NotifyInsetsUpdated();
        NotifyEnterActivityUpdated();
        NotifyWallpaperOffsetsUpdated();
    }
    private LiveWallpaperListener eventListener;

    public int insetsLeft = 0, insetsTop = 0, insetsRight = 0, insetsBottom = 0;
    public void NotifyInsetsUpdated(int left, int top, int right, int bottom, boolean force)
    {
        if (eventListener == null || LiveWallpaperManager.getInstance().unityPlayer == null)
        {
            insetsLeft = left; insetsTop = top; insetsRight = right; insetsBottom = bottom;
            return;
        }
        if (left != insetsLeft || top != insetsTop || right != insetsRight || bottom != insetsBottom || force)
        {
            insetsLeft = left; insetsTop = top; insetsRight = right; insetsBottom = bottom;
            eventListener.InsetsUpdated(left,top,right,bottom);
        }
    }
    public void NotifyInsetsUpdated(int left, int top, int right, int bottom)
    {
        NotifyInsetsUpdated(left,top,right,bottom,false);
    }
    public void NotifyInsetsUpdated()
    {
        NotifyInsetsUpdated(insetsLeft,insetsTop,insetsRight,insetsBottom,true);
    }

    public float zoom = 0;
    public void NotifyZoomUpdated(float zoomValue, boolean force)
    {
        if (eventListener == null || LiveWallpaperManager.getInstance().unityPlayer == null)
        {
            zoom = zoomValue;
            return;
        }
        if (zoom != zoomValue || force)
        {
            zoom = zoomValue;
            eventListener.WallpaperZoomUpdated(zoom);
        }
    }
    public void NotifyZoomUpdated(float zoomValue)
    {
        NotifyZoomUpdated(zoomValue, false);
    }
    public void NotifyZoomUpdated()
    {
        NotifyZoomUpdated(zoom, true);
    }



    public float xOffset = 0, yOffset = 0, xOffsetStep = 1, yOffsetStep = 1;
    public boolean simulated = true;
    public void NotifyWallpaperOffsetsUpdated(float xO, float yO, float xOS, float yOS, boolean sim, boolean force)
    {
        if (eventListener == null || LiveWallpaperManager.getInstance().unityPlayer == null)
        {
            xOffset = xO; yOffset = yO; xOffsetStep = xOS; yOffsetStep = yOS; simulated = sim;
            return;
        }
        if (xOffset != xO || yOffset != yO || xOS != xOffsetStep || yOS != yOffsetStep || simulated != sim || force)
        {
            xOffset = xO; yOffset = yO; xOffsetStep = xOS; yOffsetStep = yOS; simulated = sim;
            eventListener.WallpaperOffsetsUpdated(xO,yO,xOS,yOS,sim);
        }
    }
    public void NotifyWallpaperOffsetsUpdated(float xO, float yO, float xOS, float yOS, boolean sim)
    {
        NotifyWallpaperOffsetsUpdated(xO,yO,xOS,yOS,sim,false);
    }
    public void NotifyWallpaperOffsetsUpdated()
    {
        NotifyWallpaperOffsetsUpdated(xOffset,yOffset,xOffsetStep,yOffsetStep,simulated,true);
    }



    public enum ScreenStatus
    {
        LockedAndOff(0),
        LockedAndAOD(1),
        LockedAndOn(2),
        Unlocked(3);

        ScreenStatus(int value) {
            this.value = value;
        }
        private final int value;
        public int getValue() {
            return value;
        }
    }

    public ScreenStatus screenStatus = ScreenStatus.LockedAndAOD;
    public void NotifyScreenDisplayStatusUpdated(ScreenStatus screen, boolean force)
    {
        if (eventListener == null || LiveWallpaperManager.getInstance().unityPlayer == null)
        {
            screenStatus = screen;
            return;
        }
        if (screen != screenStatus || force)
        {
            screenStatus = screen;
            eventListener.ScreenDisplayStatusUpdated(screen.getValue());
        }
    }
    public void NotifyScreenDisplayStatusUpdated(ScreenStatus screen)
    {
        NotifyScreenDisplayStatusUpdated(screen, false);
    }
    public void NotifyScreenDisplayStatusUpdated()
    {
        NotifyScreenDisplayStatusUpdated(screenStatus, true);
    }

    public boolean darkMode = false;
    public void NotifyDarkModeEnableUpdated(boolean darkModeEnabled, boolean force)
    {
        if (eventListener == null || LiveWallpaperManager.getInstance().unityPlayer == null)
        {
            darkMode = darkModeEnabled;
            return;
        }
        if (darkMode != darkModeEnabled || force)
        {
            darkMode = darkModeEnabled;
            eventListener.DarkModeEnableUpdated(darkModeEnabled);
        }
    }
    public void NotifyDarkModeEnableUpdated(boolean darkModeEnabled)
    {
        NotifyDarkModeEnableUpdated(darkModeEnabled,false);
    }
    public void NotifyDarkModeEnableUpdated()
    {
        NotifyDarkModeEnableUpdated(darkMode, true);
    }

    public boolean isInActivity = false;
    public void NotifyEnterActivityUpdated(boolean inAct, boolean force)
    {
        if (eventListener == null || LiveWallpaperManager.getInstance().unityPlayer == null)
        {
            isInActivity = inAct;
            return;
        }
        if (isInActivity != inAct || force)
        {
            isInActivity = inAct;
            eventListener.EnterActivityUpdated(isInActivity);
        }
    }
    public void NotifyEnterActivityUpdated(boolean inAct)
    {
        NotifyEnterActivityUpdated(inAct, false);
    }
    public void NotifyEnterActivityUpdated()
    {
        NotifyEnterActivityUpdated(isInActivity, true);
    }

    public boolean isInPreview = false;
    public void NotifyServiceIsInPreviewUpdated(boolean preview, boolean force)
    {
        if (eventListener == null || LiveWallpaperManager.getInstance().unityPlayer == null)
        {
            isInPreview = preview;
            return;
        }
        if (isInPreview != preview || force)
        {
            isInPreview = preview;
            eventListener.ServiceIsInPreviewUpdated(isInPreview);
        }
    }
    public void NotifyServiceIsInPreviewUpdated(boolean preview)
    {
        NotifyServiceIsInPreviewUpdated(preview, false);
    }
    public void NotifyServiceIsInPreviewUpdated()
    {
        NotifyServiceIsInPreviewUpdated(isInPreview, true);
    }
    public void NotifySettingsButtonPressed()
    {
        if (eventListener == null) return;
        eventListener.SettingsButtonPressed();
    }
}
