package com.justzht.unity.lwp;

import android.content.Intent;
import android.content.res.Configuration;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowInsets;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;

/**
 * Wrapper for events. Typically, you should call this whenever you need to notify Unity of changes in Android part.
 */
public enum LiveWallpaperPresentationEventWrapper
{
    INSTANCE();

    /**
     * Default Singleton Instance Getter Method
     * @return Instance
     */
    public static LiveWallpaperPresentationEventWrapper getInstance() {
        return INSTANCE;
    }

    SurfaceHolder.Callback surfaceHolderCallback = new SurfaceHolder.Callback() {
        @Override
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            logD("surfaceCreated for holder " + surfaceHolder);
            LiveWallpaperManager.getInstance().connectUnityDisplay(surfaceHolder);
        }

        @Override
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
            logD("surfaceChanged for holder " + surfaceHolder);
            LiveWallpaperManager.getInstance().connectUnityDisplay(surfaceHolder);
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            logD("surfaceDestroyed for holder " + surfaceHolder);
            LiveWallpaperManager.getInstance().disconnectUnityDisplay(surfaceHolder);
        }
    };

    public void setupSurfaceViewInActivityOnCreate(SurfaceView surfaceView)
    {
        surfaceView.getHolder().addCallback(surfaceHolderCallback);
        surfaceView.setOnApplyWindowInsetsListener((v, insets) -> {
            LiveWallpaperPresentationEventWrapper.getInstance().windowInsets(insets);
            return insets;
        });
        surfaceView.requestApplyInsets();
    }

    public void setupSurfaceViewInActivityOnDestroy(SurfaceView surfaceView)
    {
        surfaceView.getHolder().removeCallback(surfaceHolderCallback);
        surfaceView.setOnApplyWindowInsetsListener(null);
    }

    public void setupSurfaceViewInDayDreamServiceOnAttachedToWindow(SurfaceView surfaceView)
    {
        surfaceView.getHolder().addCallback(surfaceHolderCallback);
    }

    public void setupSurfaceViewInDayDreamServiceOnDetachedFromWindow(SurfaceView surfaceView)
    {
        surfaceView.getHolder().removeCallback(surfaceHolderCallback);
    }

    public void setupSurfaceHolderInWallpaperServiceOnCreate(SurfaceHolder surfaceHolder)
    {
        surfaceHolder.addCallback(surfaceHolderCallback);
    }

    public void setupSurfaceHolderInWallpaperServiceOnDestroy(SurfaceHolder surfaceHolder)
    {
        surfaceHolder.removeCallback(surfaceHolderCallback);
    }

    public void configurationChanged(Configuration newConfig)
    {
        LiveWallpaperManager.getInstance().unityPlayer.configurationChanged(newConfig);
        switch (newConfig.uiMode & Configuration.UI_MODE_NIGHT_MASK) {
            case Configuration.UI_MODE_NIGHT_YES:
                LiveWallpaperListenerManager.getInstance().NotifyDarkModeEnableUpdated(true);
                break;
            case Configuration.UI_MODE_NIGHT_NO:
                LiveWallpaperListenerManager.getInstance().NotifyDarkModeEnableUpdated(false);
                break;
        }
    }

    public void onLowMemory()
    {
        logD("LiveWallpaperPresentationEventWrapper.onLowMemory");
        if (LiveWallpaperManager.getInstance().unityPlayer == null) return;
        LiveWallpaperManager.getInstance().unityPlayer.lowMemory();
    }

    public boolean touchEvent(MotionEvent event, int[] additionalOffset)
    {
        if (LiveWallpaperManager.getInstance().unityPlayer == null){
            return true;
        }else
        {
            event.offsetLocation(additionalOffset[0], additionalOffset[1]);
            return LiveWallpaperManager.getInstance().unityPlayer.onTouchEvent(event);
        }
    }

    public void windowInsets(WindowInsets insets)
    {
        if (insets == null) return;
        LiveWallpaperListenerManager.getInstance().NotifyInsetsUpdated(
                insets.getSystemWindowInsetLeft(),
                insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(),
                insets.getSystemWindowInsetBottom()
        );
    }

    public void windowInsets(int left, int top, int right, int bottom)
    {
        LiveWallpaperListenerManager.getInstance().NotifyInsetsUpdated(left,top,right,bottom);
    }

    public void offsets(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, boolean simulated)
    {
        LiveWallpaperListenerManager.getInstance().NotifyWallpaperOffsetsUpdated(xOffset,yOffset,xOffsetStep,yOffsetStep,simulated);
    }

    public void zoom(float zoomScale)
    {
        LiveWallpaperListenerManager.getInstance().NotifyZoomUpdated(zoomScale);
    }

    public void serviceIsInPreview(boolean preview)
    {
        LiveWallpaperListenerManager.getInstance().NotifyServiceIsInPreviewUpdated(preview);
    }

    public void serviceVisibility(boolean visible, SurfaceHolder surfaceHolder)
    {
        if (LiveWallpaperManager.getInstance().unityPlayer == null) return;
        if (visible)
        {
            LiveWallpaperManager.getInstance().connectUnityDisplay(surfaceHolder);
        }else
        {
            LiveWallpaperManager.getInstance().disconnectUnityDisplay(surfaceHolder);
        }
    }

    public void activityVisibility(boolean visible, SurfaceHolder surfaceHolder)
    {
        LiveWallpaperListenerManager.getInstance().NotifyEnterActivityUpdated(visible);
    }

    public void intent(Intent intent)
    {
        if (LiveWallpaperManager.getInstance().unityPlayer == null) return;
        LiveWallpaperManager.getInstance().unityPlayer.newIntent(intent);
    }
}
