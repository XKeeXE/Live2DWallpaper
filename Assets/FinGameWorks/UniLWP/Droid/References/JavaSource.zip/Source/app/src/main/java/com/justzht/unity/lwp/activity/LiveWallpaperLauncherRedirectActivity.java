package com.justzht.unity.lwp.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.justzht.unity.lwp.LiveWallpaperManager;

public class LiveWallpaperLauncherRedirectActivity extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        switch (LiveWallpaperManager.getInstance().liveWallpaperConfig.launcherActivityDisplayStyle) {
            case UnityFullscreen:
            case UnityStable:
                startActivity(new Intent(LiveWallpaperManager.getInstance().getContext(), LiveWallpaperPresentationActivity.class));
                break;
            case Preference:
                startActivity(new Intent(LiveWallpaperManager.getInstance().getContext(), LiveWallpaperPreferenceActivity.class));
                break;
        }
        finish();
    }
}
