package com.justzht.unity.lwp.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;

import com.justzht.unity.lwp.R;
import com.justzht.unity.lwp.preference.LiveWallpaperPreferenceManager;
import com.justzht.unity.lwp.preference.PreferenceUtils;

public class LiveWallpaperPreferenceActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (PreferenceUtils.moduleLoaded())
        {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(android.R.id.content, new SettingsFragment())
                    .commit();
        }
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            getPreferenceManager().setSharedPreferencesName(LiveWallpaperPreferenceManager.getInstance().getPreferenceName());
            setPreferencesFromResource(R.xml.unilwp_preference_screen, rootKey);
        }
    }
}
