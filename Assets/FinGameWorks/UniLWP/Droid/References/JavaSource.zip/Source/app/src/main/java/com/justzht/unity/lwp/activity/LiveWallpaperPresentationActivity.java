package com.justzht.unity.lwp.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;

import com.justzht.unity.lwp.LiveWallpaperManager;
import com.justzht.unity.lwp.LiveWallpaperPresentationEventWrapper;
import com.justzht.unity.lwp.R;
import com.unity3d.player.UnityPlayer;

public class LiveWallpaperPresentationActivity extends Activity
{
    protected SurfaceView surfaceView;
    protected UnityPlayer mUnityPlayer; // don't change the name of this variable; referenced from native code

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        UnityPlayer.currentActivity = this;
        mUnityPlayer = LiveWallpaperManager.getInstance().unityPlayer;
        switch (LiveWallpaperManager.getInstance().liveWallpaperConfig.launcherActivityDisplayStyle)
        {
            case UnityStable:
                this.requestWindowFeature(Window.FEATURE_NO_TITLE);
                setTheme(R.style.Theme_UniLWP_Expanded);
                getWindow().getDecorView().setSystemUiVisibility(0);
                getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
                break;
            default:
            case UnityFullscreen:
                this.requestWindowFeature(Window.FEATURE_NO_TITLE);
                setTheme(R.style.Theme_UniLWP_FullScreen);
                getWindow().getDecorView().setSystemUiVisibility(0);
                getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_IMMERSIVE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN);
                getWindow().setNavigationBarColor(Color.TRANSPARENT);
                getWindow().setStatusBarColor(Color.TRANSPARENT);
                break;
        }
        super.onCreate(savedInstanceState);
        surfaceView = new SurfaceView(this);
        setContentView(surfaceView);
        LiveWallpaperPresentationEventWrapper.getInstance().setupSurfaceViewInActivityOnCreate(surfaceView);
    }

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        surfaceView.requestApplyInsets();
    }

    @Override
    protected void onStart() {
        super.onStart();
        surfaceView.requestApplyInsets();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        LiveWallpaperPresentationEventWrapper.getInstance().intent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        LiveWallpaperPresentationEventWrapper.getInstance().activityVisibility(true, surfaceView.getHolder());
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        LiveWallpaperPresentationEventWrapper.getInstance().onLowMemory();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        LiveWallpaperPresentationEventWrapper.getInstance().onLowMemory();
    }

    @Override
    protected void onPause() {
        LiveWallpaperPresentationEventWrapper.getInstance().activityVisibility(false, surfaceView.getHolder());
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LiveWallpaperPresentationEventWrapper.getInstance().setupSurfaceViewInActivityOnDestroy(surfaceView);
    }

    @Override public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
        LiveWallpaperPresentationEventWrapper.getInstance().configurationChanged(newConfig);
        surfaceView.requestApplyInsets();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int[] windowPos = new int[2];
        surfaceView.getLocationInWindow(windowPos);
        return LiveWallpaperPresentationEventWrapper.getInstance().touchEvent(event, new int[]{-windowPos[0],-windowPos[1]});
    }
}
