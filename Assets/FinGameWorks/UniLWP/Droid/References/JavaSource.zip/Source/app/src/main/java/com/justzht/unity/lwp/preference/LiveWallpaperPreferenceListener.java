package com.justzht.unity.lwp.preference;

public interface LiveWallpaperPreferenceListener
{
    void PreferenceUpdated(String key, Boolean value);
    void PreferenceUpdated(String key, String value);
    void PreferenceUpdated(String key, Integer value);
    void PreferenceUpdated(String key, Float value);
}
