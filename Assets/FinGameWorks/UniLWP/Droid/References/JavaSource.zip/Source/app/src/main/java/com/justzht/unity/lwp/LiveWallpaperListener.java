package com.justzht.unity.lwp;

/**
 * Interface for outside events that are about to be passed into Unity
 */
public interface LiveWallpaperListener
{
    void InsetsUpdated(int left, int top, int right, int bottom);
    void ScreenDisplayStatusUpdated(int status);
    void WallpaperOffsetsUpdated(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, boolean simulated);
    void WallpaperZoomUpdated(float zoom);
    void DarkModeEnableUpdated(boolean enabled);
    void EnterActivityUpdated(boolean inActivity);
    void ServiceIsInPreviewUpdated(boolean preview);
    void SettingsButtonPressed();
}

