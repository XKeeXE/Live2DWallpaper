package com.justzht.unity.lwp;

import android.app.Activity;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.WindowManager;

import com.justzht.unity.lwp.activity.LiveWallpaperUnityCheckBypassActivity;
import com.justzht.unity.lwp.config.LiveWallpaperConfig;
import com.justzht.unity.lwp.config.LiveWallpaperConfigManager;
import com.unity3d.player.IUnityPlayerLifecycleEvents;
import com.unity3d.player.UnityPlayer;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;
import static com.justzht.unity.lwp.LiveWallpaperUtils.logE;

public enum LiveWallpaperManager implements IUnityPlayerLifecycleEvents
{
    INSTANCE();

    /**
     * Default Singleton Instance Getter Method
     * @return Instance
     */
    public static LiveWallpaperManager getInstance() {
        return INSTANCE;
    }

    /**
     * Unity Instance, preferred type is UnityPlayer, while {@link LiveWallpaperPlayer LiveWallpaperPlayer} is better at handling compatibility issues
     */
    public LiveWallpaperPlayer unityPlayer;
    private WeakReference<Context> applicationContextWeakReference = new WeakReference<>(null);
    public Context getContext()
    {
        return applicationContextWeakReference.get();
    }
    public boolean hasContext()
    {
        return getContext() != null;
    }
    public LiveWallpaperConfig liveWallpaperConfig;

    private static final int displayIndex = 0;
    private volatile Timer countDown = new Timer();
    private volatile TimerTask countDownTask = null;
    private volatile HashMap<Integer,WeakReference<SurfaceHolder>> holdersOfUnity = new HashMap<>();
    public volatile boolean unityInstancePaused = true;
    private LiveWallpaperScreenBroadcastReceiver screenBroadcastReceiver = new LiveWallpaperScreenBroadcastReceiver();

    // for single thread and timer
    private Handler unityRunnerThreadHandler;
    private HandlerThread unityRunnerThread = new HandlerThread("UniLWP-Threading");
    // for multi thread
    private ExecutorService unityRunnerThreadExecutorService = Executors.newCachedThreadPool(new LiveWallpaperExecutionThreadFactory());

    // called by Unity side to assign Android Proxy Interface
    public void setEventListener(LiveWallpaperListener listener)
    {
        logD("setEventListener -> " + listener);
        LiveWallpaperListenerManager.getInstance().setEventListener(listener);
    }

    public void Init(Context applicationContext)
    {
        logD("Init -> " + applicationContext);
        liveWallpaperConfig = LiveWallpaperConfigManager.getInstance().getConfig(applicationContext);
        logD("UniLWP Config -> " + liveWallpaperConfig);
        applicationContextWeakReference = new WeakReference<>(applicationContext);
        unityRunnerThread.start();
        unityRunnerThreadHandler = new Handler(unityRunnerThread.getLooper());
        if (!liveWallpaperConfig.isIsolateMode)
        {
            applicationContext.registerReceiver(screenBroadcastReceiver,new IntentFilter()
            {{
                addAction(Intent.ACTION_SCREEN_ON);
                addAction(Intent.ACTION_USER_PRESENT);
                addAction(Intent.ACTION_SCREEN_OFF);
            }});
        }
        if (!liveWallpaperConfig.isIsolateMode)
        {
            logD("LoadUnity, activityEarlyInit = " + liveWallpaperConfig.bypassInitialActivityCheck + " UnityPlayer.currentActivity = " + UnityPlayer.currentActivity);
            if (liveWallpaperConfig.bypassInitialActivityCheck && UnityPlayer.currentActivity == null)
            {
                Intent intent = new Intent("android.intent.category.LAUNCHER");
                intent.setClass(applicationContext, LiveWallpaperUnityCheckBypassActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                applicationContext.startActivity(intent);
            }
            LoadUnity(applicationContext);
        }
    }

    public void DeInit(Context applicationContext)
    {
        logD("LiveWallpaperManager.DeInit");
        applicationContext.unregisterReceiver(screenBroadcastReceiver);
        UnloadUnity();
        unityPlayer.quit();
    }

    public void pauseUnity()
    {
        if (!unityInstancePaused)
        {
            logD("main thread: " + (Looper.myLooper() == Looper.getMainLooper()));
            unityInstancePaused = true;
            logD("calling unityPlayer.pause");
            unityPlayer.pause();
            logD("calling unityPlayer.windowFocusChanged false");
            unityPlayer.windowFocusChanged(false);
        }
    }

    public void resumeUnity()
    {
        if (unityInstancePaused)
        {
            logD("main thread: " + (Looper.myLooper() == Looper.getMainLooper()));
            unityInstancePaused = false;
            logD("calling unityPlayer.resume");
            unityPlayer.resume();
            unityPlayer.executeGLThreadJobs();
            logD("calling unityPlayer.windowFocusChanged true");
            unityPlayer.windowFocusChanged(true);
        }
    }

    public void LoadUnity(Context context)
    {
        logD("LiveWallpaperManager.LoadUnity " + context);
        logD("context.getPackageName() -> " + context.getPackageName());
        logD("getResources.getIdentifier() -> " + context.getResources().getIdentifier("game_view_content_description", "string", context.getPackageName()));
        unityPlayer = new LiveWallpaperPlayer(context, this);
        unityPlayer.requestFocus();
    }

    public void UnloadUnity()
    {
        logD("LiveWallpaperManager.UnloadUnity");
        unityPlayer.unload();
    }

    public synchronized void connectUnityDisplay(SurfaceHolder holder)
    {
        if (liveWallpaperConfig.isIsolateMode)
        {
           return;
        }
        cleanUpHolders(holder);
        int nextIndex = holdersOfUnity.size();
        WeakReference<SurfaceHolder> reference = new WeakReference<>(holder);
        logD(String.format("holdersOfUnity.put(%s, %s)", nextIndex, holder));
        holdersOfUnity.put(nextIndex,reference);
        updateLifeStageUsingBackingCount();
    }

    public synchronized void disconnectUnityDisplay(SurfaceHolder holder)
    {
        if (liveWallpaperConfig.isIsolateMode)
        {
            return;
        }
        cleanUpHolders(holder);
        updateLifeStageUsingBackingCount();
    }

    private synchronized void cleanUpHolders()
    {
        cleanUpHolders(null);
    }

    private synchronized void cleanUpHolders(SurfaceHolder holderToRemove)
    {
        List<WeakReference<SurfaceHolder>> surfaceRefs = holdersOfUnity.values()
                .stream()
                .filter(ref -> ref != null && ref.get() != holderToRemove)
                .collect(Collectors.toList());
        holdersOfUnity.clear();
        for (int i = 0; i < surfaceRefs.size(); i++) {
            holdersOfUnity.put(i, surfaceRefs.get(i));
        }
    }

    private synchronized void updateLifeStageUsingBackingCount()
    {
        logD(System.lineSeparator());
        String transactionID = UUID.randomUUID().toString();
        logD(String.format("updateLifeStageUsingBackingCount start transactionID %s", transactionID));
        if (liveWallpaperConfig.isIsolateMode)
        {
            return;
        }
        cleanUpHolders();
        int surfaceHolderCount = holdersOfUnity.size();
        boolean hasHolder = surfaceHolderCount > 0;
        Integer newestSurfaceHolderKey = Math.max(surfaceHolderCount - 1, 0);
        WeakReference<SurfaceHolder> surfaceHolderReference = holdersOfUnity.getOrDefault(newestSurfaceHolderKey, null);
        SurfaceHolder surfaceHolder = surfaceHolderReference == null ? null : surfaceHolderReference.get();
        Surface surface = surfaceHolder == null ? null : surfaceHolder.getSurface();
        logD(String.format(
                "transactionID %s surfaceHolderCount %s hasHolder %s unityInstancePaused %s newestSurfaceHolderKey %s surfaceHolderReference %s surfaceHolder %s surface %s holdersOfUnity %s",
                transactionID,
                surfaceHolderCount,
                hasHolder,
                unityInstancePaused,
                newestSurfaceHolderKey,
                surfaceHolderReference,
                surfaceHolder,
                surface,
                holdersOfUnity
        ));
        Runnable updateRunnable = () -> {
            logD(String.format(Locale.getDefault(), "updateRunnable.scheduled task transactionID %s now run after %d ms", transactionID, liveWallpaperConfig.surfaceUpdateInterval));
            if (hasHolder)
            {
                logD(String.format("calling unityPlayer.displayChanged(%s, %s)", displayIndex, surface));
                boolean changed = unityPlayer.displayChanged(displayIndex, surface); // let unity cast to that surface with newestDisplayIndex as the Display index in Unity
                logD(String.format("calling unityPlayer.displayChanged result %s", changed));
            } else {
                logE("unityDisplaySwitchRunnable No Holder");
            }
            if (hasHolder && unityInstancePaused) {
                resumeUnity();
            } else if (!hasHolder && !unityInstancePaused) {
                pauseUnity();
            }
        };
        if (liveWallpaperConfig.surfaceUpdateInterval <= 0)
        {
            updateRunnable.run();
        } else
        {
            if (countDownTask != null)
            {
                boolean cancel = countDownTask.cancel();
                logD("updateTask.cancel -> " + cancel);
            }
            countDownTask = new TimerTask() {
                @Override
                public void run() {
                    unityRunnerThreadHandler.post(updateRunnable);
                }
            };
            countDown.schedule(countDownTask, liveWallpaperConfig.surfaceUpdateInterval);
            logD("countDown.schedule in " + liveWallpaperConfig.surfaceUpdateInterval + " ms");
        }
        logD(String.format("updateLifeStageUsingBackingCount end transactionID %s", transactionID));
        logD(System.lineSeparator());
    }

    @Override public void onUnityPlayerUnloaded() {
        logD("onUnityPlayerUnloaded");
    }

    @Override public void onUnityPlayerQuitted() {
        logD("onUnityPlayerQuitted");
    }

    /**
     * Detect if the live wallpaper in this package is set as system wallpaper
     * @return Boolean value of wallpaper set info
     */
    public boolean isWallpaperSet()
    {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(getContext());
        WallpaperInfo info = wallpaperManager.getWallpaperInfo();
        return (info != null && info.getPackageName().equals(getContext().getPackageName()));
    }

    public boolean isUnityDisplaying()
    {
        return !holdersOfUnity.isEmpty();
    }

    public void openLiveWallpaperPreview(String serviceClassName)
    {
        try {
            openLiveWallpaperPreview((Class<? extends WallpaperService>) Class.forName(serviceClassName));
        } catch (ClassNotFoundException e) {
            logE(e.toString());
            e.printStackTrace();
        }
    }

    public void openLiveWallpaperPreview(Class<? extends WallpaperService> serviceClass)
    {
        Context context = getContext();
        Intent intent;

        try {
            intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(context, serviceClass));
            context.startActivity(intent);
            return;
        }
        catch (Exception e)
        {
            logE(e.toString());
        }

        try {
            intent = new Intent(Intent.ACTION_SET_WALLPAPER);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY);
        }
        catch (Exception e)
        {
            logE(e.toString());
        }
    }

    public void openLiveWallpaperPreview()
    {
        openLiveWallpaperPreview(liveWallpaperConfig.wallpaperServiceClass);
    }

    public void removePreviousWallpaper()
    {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(getInstance().getContext());
        try {
            wallpaperManager.clear();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void launchUnityActivity()
    {
        launchUnityActivity(liveWallpaperConfig.launcherActivityClass);
    }
    public void launchUnityActivity(Class<? extends Activity> activityClass)
    {
        Intent intent = new Intent(this.getContext(), activityClass);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.getContext().startActivity(intent);
    }
    public void launchUnityActivity(String activityName)
    {
        try {
            launchUnityActivity((Class<? extends Activity>) Class.forName(activityName));
        } catch (ClassNotFoundException e) {
            logE(e.toString());
            e.printStackTrace();
        }
    }

    public void launchUnityService()
    {
        launchUnityService(liveWallpaperConfig.wallpaperServiceClass);
    }
    public void launchUnityService(Class<? extends WallpaperService> serviceClass)
    {
        getContext().startService(new Intent(getContext(), serviceClass));
    }

    public WindowManager getWindowManager()
    {
        return (WindowManager) this.getContext().getSystemService(Context.WINDOW_SERVICE);
    }
}
