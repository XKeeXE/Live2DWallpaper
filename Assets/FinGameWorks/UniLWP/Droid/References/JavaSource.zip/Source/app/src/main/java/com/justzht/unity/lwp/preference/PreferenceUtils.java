package com.justzht.unity.lwp.preference;

public class PreferenceUtils
{
    public static boolean moduleLoaded()
    {
        try  {
            Class.forName("androidx.preference.PreferenceFragmentCompat");
            return true;
        }  catch (ClassNotFoundException e) {
            return false;
        }
    }
}
