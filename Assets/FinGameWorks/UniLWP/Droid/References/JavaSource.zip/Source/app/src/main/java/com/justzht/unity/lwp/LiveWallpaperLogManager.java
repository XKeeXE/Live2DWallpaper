package com.justzht.unity.lwp;

public enum LiveWallpaperLogManager
{
    INSTANCE;
    public static LiveWallpaperLogManager getInstance() { return INSTANCE; }
    public interface LiveWallpaperLogInterface
    {
        void logI(String s);
        void logD(String s);
        void logW(String s);
        void logE(String s);
    }
    public boolean hasExternalLogger() {
        return logInterface != null;
    }
    public void setLogInterface(LiveWallpaperLogInterface logInterface) {
        this.logInterface = logInterface;
    }

    public LiveWallpaperLogInterface getLogInterface() {
        return logInterface;
    }

    private LiveWallpaperLogInterface logInterface;
}
