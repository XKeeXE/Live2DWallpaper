package com.justzht.unity.lwp.activity;

import android.app.Activity;
import android.os.Bundle;

import com.justzht.unity.lwp.LiveWallpaperManager;
import com.unity3d.player.UnityPlayer;

public class LiveWallpaperUnityCheckBypassActivity extends Activity
{
    protected UnityPlayer mUnityPlayer; // don't change the name of this variable; referenced from native code

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UnityPlayer.currentActivity = this;
        mUnityPlayer = LiveWallpaperManager.getInstance().unityPlayer;
        finish();
    }
}
