package com.justzht.unity.lwp;

import android.os.Looper;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;
import static com.justzht.unity.lwp.LiveWallpaperUtils.logE;

public class LiveWallpaperExecutionThread extends Thread {
    private Runnable target;

    public LiveWallpaperExecutionThread(ThreadGroup group, Runnable target, String name) {
        super(group,name);
        this.target = target;
        logD(String.format("%s init",name));
    }

    @Override
    public void run() {
        Looper.prepare();
        logD(String.format("%s run start",getName()));
        if (target != null) {
            target.run();
        }else
        {
            logE(String.format("%s have no target",getName()));
        }
        logD(String.format("%s run end",getName()));
        logD(String.format("%s looper loop",getName()));
        Looper.loop();
    }
}
