package com.justzht.unity.lwp.service;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.service.wallpaper.WallpaperService;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.WindowInsets;

import com.justzht.unity.lwp.LiveWallpaperManager;
import com.justzht.unity.lwp.LiveWallpaperPresentationEventWrapper;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;


public class LiveWallpaperPresentationService extends WallpaperService
{
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        logD("onStartCommand " + intent.toString() + " " + flags + " " + startId);
        logD("LiveWallpaperManager.getInstance().isWallpaperSet -> " + LiveWallpaperManager.getInstance().isWallpaperSet());
        return START_STICKY;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        logD("onConfigurationChanged");
        LiveWallpaperPresentationEventWrapper.getInstance().configurationChanged(newConfig);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        logD("onCreate");
    }

    @Override
    public void onRebind(Intent intent) {
        logD("onRebind");
        super.onRebind(intent);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        logD("onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        logD("onDestroy");
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        logD("onTaskRemoved " + rootIntent);
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
        logD("onLowMemory");
        LiveWallpaperPresentationEventWrapper.getInstance().onLowMemory();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        logD("onTrimMemory");
        LiveWallpaperPresentationEventWrapper.getInstance().onLowMemory();
    }

    @Override
    public Engine onCreateEngine()
    {
        logD("onCreateEngine");
        return new LiveWallpaperPresentationServiceEngine();
    }

    public class LiveWallpaperPresentationServiceEngine extends WallpaperService.Engine
    {
        boolean stockBehavior = false;
        GestureDetector gestureDetector;
        private final GestureDetector.SimpleOnGestureListener gestureListener = new GestureDetector.SimpleOnGestureListener() {
            private float xOffset = 0f;
            int pageCount = 1; // god knows how many pages

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                float newXOffset = xOffset + distanceX / getDesiredMinimumWidth() / pageCount; // 1 page width
                if (newXOffset > 1) {
                    newXOffset = 1f;
                } else if (newXOffset < 0) {
                    newXOffset = 0f;
                }
                xOffset = newXOffset;
                LiveWallpaperPresentationEventWrapper.getInstance().offsets(xOffset, 0, 1.0f / (pageCount > 2 ? pageCount : 1), 1.0f, true);
                return super.onScroll(e1, e2, distanceX, distanceY);
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                float boundary = velocityX < 0 ? 1 : 0;
                xOffset = xOffset + (boundary - xOffset) * 0.2f;
                LiveWallpaperPresentationEventWrapper.getInstance().offsets(xOffset, 0, 1.0f / (pageCount > 2 ? pageCount : 1), 1.0f, true);
                return true;
            }
        };

        LiveWallpaperPresentationServiceEngine() {
            logD("LiveWallpaperPresentationServiceEngine");
            setTouchEventsEnabled(true);
            setOffsetNotificationsEnabled(true);
        }

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            logD("onCreate");
            gestureDetector = new GestureDetector(LiveWallpaperManager.getInstance().getContext(), gestureListener);
            LiveWallpaperPresentationEventWrapper.getInstance().setupSurfaceHolderInWallpaperServiceOnCreate(surfaceHolder);
        }

        @Override
        public void onApplyWindowInsets(WindowInsets insets) {
            super.onApplyWindowInsets(insets);
            LiveWallpaperPresentationEventWrapper.getInstance().windowInsets(insets);
        }

        @Override
        public void onTouchEvent(MotionEvent event) {
            super.onTouchEvent(event);
            LiveWallpaperPresentationEventWrapper.getInstance().touchEvent(event, new int[]{0,0});
            if (!stockBehavior) { gestureDetector.onTouchEvent(event); }
        }

        @Override
        public void onZoomChanged(float zoom) {
            super.onZoomChanged(zoom);
            LiveWallpaperPresentationEventWrapper.getInstance().zoom(zoom);
        }

        @Override
        public void onDesiredSizeChanged(int desiredWidth, int desiredHeight) {
            super.onDesiredSizeChanged(desiredWidth, desiredHeight);
            logD("onDesiredSizeChanged " + desiredWidth + "," + desiredHeight);
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset) {
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset);
            if (!stockBehavior && xOffset != 0.0f && xOffset != 0.5f) {
                stockBehavior = true;
                logD("stockBehavior = true xOffset = " + xOffset);
            }
            if (stockBehavior)
            {
                LiveWallpaperPresentationEventWrapper.getInstance().offsets(xOffset, yOffset, xOffsetStep, yOffsetStep, false);
            }
        }

        //TODO: let service instead of engine to handle and report onVisibilityChanged events, as there might be multiple engines (e.g. a preview and a wallpaper and they are called with different times, often distracting each other)
        @Override
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);
            logD("onVisibilityChanged visible = " + visible + " isPreview = " + isPreview());
            LiveWallpaperPresentationEventWrapper.getInstance().serviceIsInPreview(isPreview());
            LiveWallpaperPresentationEventWrapper.getInstance().serviceVisibility(visible, getSurfaceHolder());
        }

        @Override
        public Bundle onCommand(String action, int x, int y, int z, Bundle extras, boolean resultRequested) {
            return super.onCommand(action, x, y, z, extras, resultRequested);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            LiveWallpaperPresentationEventWrapper.getInstance().setupSurfaceHolderInWallpaperServiceOnDestroy(getSurfaceHolder());
            logD("onDestroy");
        }
    }
}
