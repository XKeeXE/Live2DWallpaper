package com.justzht.unity.lwp.config;

import android.content.Context;

import com.justzht.unity.lwp.LiveWallpaperManager;

public enum LiveWallpaperConfigManager
{
    INSTANCE;

    public static LiveWallpaperConfigManager getInstance()
    {
        return INSTANCE;
    }

    /**
     * Return a config based on current context
     * @param context context
     * @return Config
     */
    public LiveWallpaperConfig getConfig(Context context)
    {
        return new LiveWallpaperConfig(context);
    }

    /**
     * Only use this when {@link LiveWallpaperManager is fully init-ed}
     * @return Config
     */
    public LiveWallpaperConfig getConfig()
    {
        return new LiveWallpaperConfig(LiveWallpaperManager.getInstance().getContext());
    }

    public LiveWallpaperConfig getConfigDefault()
    {
        return new LiveWallpaperConfig();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
