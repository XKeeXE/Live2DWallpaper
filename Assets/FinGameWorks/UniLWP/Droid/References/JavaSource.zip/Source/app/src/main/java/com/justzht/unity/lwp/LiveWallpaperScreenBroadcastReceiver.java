package com.justzht.unity.lwp;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.view.Display;
import android.view.WindowManager;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;

public class LiveWallpaperScreenBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        logD("Action = " + action);
        if (action == null) return;
        switch (action)
        {
            case Intent.ACTION_USER_PRESENT:
            {
                LiveWallpaperListenerManager.getInstance().NotifyScreenDisplayStatusUpdated(LiveWallpaperListenerManager.ScreenStatus.Unlocked);
                logD("LiveWallpaperScreenBroadcastReceiver => Unlocked");
                break;
            }
            case Intent.ACTION_SCREEN_ON:
            {
                KeyguardManager keyguardManager = (KeyguardManager) LiveWallpaperManager.getInstance().getContext().getSystemService(Context.KEYGUARD_SERVICE);
                assert keyguardManager != null;
                if (keyguardManager.isKeyguardLocked())
                {
                    LiveWallpaperListenerManager.getInstance().NotifyScreenDisplayStatusUpdated(LiveWallpaperListenerManager.ScreenStatus.LockedAndOn);
                    logD("LiveWallpaperScreenBroadcastReceiver => LockedAndOn");
                }else
                {
                    LiveWallpaperListenerManager.getInstance().NotifyScreenDisplayStatusUpdated(LiveWallpaperListenerManager.ScreenStatus.Unlocked);
                    logD("LiveWallpaperScreenBroadcastReceiver => Unlocked");
                }
                break;
            }
            case Intent.ACTION_SCREEN_OFF:
            {
                WindowManager windowManager = (WindowManager) LiveWallpaperManager.getInstance().getContext().getSystemService(Context.WINDOW_SERVICE);
                assert windowManager != null;
                Display defaultDisplay = windowManager.getDefaultDisplay();
                switch (defaultDisplay.getState()) {
                    case Display.STATE_ON:
                    case Display.STATE_OFF:
                    {
                        if (LiveWallpaperManager.getInstance().liveWallpaperConfig.earlyTriggerScreenOff)
                        {
                            LiveWallpaperManager.getInstance().resumeUnity();
                        }
                        LiveWallpaperListenerManager.getInstance().NotifyScreenDisplayStatusUpdated(LiveWallpaperListenerManager.ScreenStatus.LockedAndOff);
                        logD("LiveWallpaperScreenBroadcastReceiver => LockedAndOff");
                        if (LiveWallpaperManager.getInstance().liveWallpaperConfig.earlyTriggerScreenOff)
                        {
                            LiveWallpaperManager.getInstance().pauseUnity();
                        }
                        break;
                    }
                    case Display.STATE_DOZE:
                    {
                        LiveWallpaperListenerManager.getInstance().NotifyScreenDisplayStatusUpdated(LiveWallpaperListenerManager.ScreenStatus.LockedAndAOD);
                        logD("LiveWallpaperScreenBroadcastReceiver => LockedAndAOD");
                        break;
                    }
                }
                break;
            }
        }
    }

    public static LiveWallpaperListenerManager.ScreenStatus getStatus()
    {
        KeyguardManager keyguardManager = (KeyguardManager) LiveWallpaperManager.getInstance().getContext().getSystemService(Context.KEYGUARD_SERVICE);
        PowerManager powerManager = (PowerManager) LiveWallpaperManager.getInstance().getContext().getSystemService(Context.POWER_SERVICE);
        WindowManager windowManager = (WindowManager) LiveWallpaperManager.getInstance().getContext().getSystemService(Context.WINDOW_SERVICE);

        if (windowManager == null || keyguardManager == null || powerManager == null) return LiveWallpaperListenerManager.ScreenStatus.Unlocked;

        logD("Locked " + keyguardManager.isKeyguardLocked() + " Interactive " + powerManager.isInteractive());

        if (powerManager.isInteractive())
        {
            if (keyguardManager.isKeyguardLocked())
            {
                return LiveWallpaperListenerManager.ScreenStatus.LockedAndOn;
            }else
            {
                return LiveWallpaperListenerManager.ScreenStatus.Unlocked;
            }
        }else
        {
            return LiveWallpaperListenerManager.ScreenStatus.LockedAndOff;
        }

    }
}
