package com.justzht.unity.lwp.service;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.service.dreams.DreamService;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;

import com.justzht.unity.lwp.LiveWallpaperManager;
import com.justzht.unity.lwp.LiveWallpaperPresentationEventWrapper;

public class LiveWallpaperScreenSaverService extends DreamService
{
    SurfaceView surfaceView;
    SurfaceHolder.Callback surfaceHolderCallback = new SurfaceHolder.Callback() {
        @Override
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            logD("surfaceCreated for holder " + surfaceHolder);
            LiveWallpaperManager.getInstance().connectUnityDisplay(surfaceHolder);
        }

        @Override
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
            logD("surfaceChanged for holder " + surfaceHolder + " format " + i + " width " + i1 + " height " + i2);
            LiveWallpaperManager.getInstance().connectUnityDisplay(surfaceHolder);
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            logD("surfaceDestroyed for holder " + surfaceHolder);
            LiveWallpaperManager.getInstance().disconnectUnityDisplay(surfaceHolder);
        }
    };

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        surfaceView = new SurfaceView(this);
        surfaceView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(surfaceView);
        setFullscreen(true);
        getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility()
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        surfaceView.getHolder().addCallback(surfaceHolderCallback);
    }

    @Override
    public void onDetachedFromWindow() {
        surfaceView.getHolder().removeCallback(surfaceHolderCallback);
        super.onDetachedFromWindow();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
    }

    @Override
    public void onDreamingStarted() {
        super.onDreamingStarted();
        LiveWallpaperManager.getInstance().connectUnityDisplay(surfaceView.getHolder());
    }

    @Override
    public void onDreamingStopped() {
        super.onDreamingStopped();
        LiveWallpaperManager.getInstance().disconnectUnityDisplay(surfaceView.getHolder());
    }
}
