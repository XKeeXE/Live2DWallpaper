package com.justzht.unity.lwp.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.justzht.unity.lwp.LiveWallpaperListenerManager;
import com.justzht.unity.lwp.LiveWallpaperManager;
import com.justzht.unity.lwp.config.LiveWallpaperConfig;

import static com.justzht.unity.lwp.LiveWallpaperUtils.logD;

public class LiveWallpaperSettingsRedirectActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LiveWallpaperConfig.PreviewSettingButtonBehaviour settingButtonBehaviour = LiveWallpaperManager.getInstance().liveWallpaperConfig.previewSettingButtonBehaviour;
        logD("LiveWallpaperSettingsRedirectActivity.onCreate with settingButtonBehaviour " + settingButtonBehaviour);
        Class<? extends Activity> launcherActivityClass = LiveWallpaperManager.getInstance().liveWallpaperConfig.launcherActivityClass;
        switch (settingButtonBehaviour)
        {
            case StartLauncherActivity:
                startActivity(new Intent(LiveWallpaperManager.getInstance().getContext(), launcherActivityClass));
                break;
            case NotifyUnity:
                LiveWallpaperListenerManager.getInstance().NotifySettingsButtonPressed();
                break;
            case Both:
                LiveWallpaperListenerManager.getInstance().NotifySettingsButtonPressed();
                startActivity(new Intent(LiveWallpaperManager.getInstance().getContext(), launcherActivityClass));
                break;
        }
        finish();
    }
}
