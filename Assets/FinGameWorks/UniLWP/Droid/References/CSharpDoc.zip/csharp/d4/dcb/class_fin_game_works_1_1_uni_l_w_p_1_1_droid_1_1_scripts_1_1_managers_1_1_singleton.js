var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton =
[
    [ "OnAwake", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html#ae708acfe7e18dd663e924fd0c7b4dae0", null ],
    [ "Instance", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html#a928f0a232f50d43a7e9cdaf7cf43d338", null ],
    [ "Quitting", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html#a560e5e5ab164b1e438784ace91c36e1e", null ]
];