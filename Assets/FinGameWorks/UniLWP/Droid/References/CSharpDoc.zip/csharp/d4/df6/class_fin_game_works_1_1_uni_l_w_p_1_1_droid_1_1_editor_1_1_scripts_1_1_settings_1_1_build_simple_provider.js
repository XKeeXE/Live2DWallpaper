var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider =
[
    [ "BuildSimpleProvider", "d4/df6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider.html#a39d1ea744d9effc5786ee50f3c0d5fcb", null ],
    [ "Build", "d4/df6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider.html#ae0f7a3f64b5af0ee7669bc453a759bf7", null ],
    [ "CreateMyCustomSettingsProvider", "d4/df6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider.html#a6e7092878944726b612273a7a7dc0f68", null ],
    [ "Path", "d4/df6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider.html#aa38505849f355e91e85c4f6b942a3715", null ]
];