var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider =
[
    [ "ResourcesProvider", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html#a1c2bd8eee68160422ae01fb06d2ce9fe", null ],
    [ "CreateMyCustomSettingsProvider", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html#a23a29a1ddb51b4d83b22292d1a4f4778", null ],
    [ "GetPluginPath", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html#a2e6517e53152f27ccd101cb50751c7ab", null ],
    [ "PluginExist", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html#ad25b040e1737768e0a7fa8111f154559", null ],
    [ "Path", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html#a0626cd7e21764c6ade6371f12d76746d", null ],
    [ "PluginPathRelative", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html#ab65c5b51989a1db28ccb466a6b5d7451", null ]
];