var searchData=
[
  ['xmlns_369',['xmlns',['../d0/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_manifest_xml.html#adbd5e6817e858cc9d8576a4ae79b86f7',1,'FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidManifestXml.xmlns()'],['../da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a7fca00a5d7d346bb34e03fd3cac4bd00',1,'FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidWallpaperXml.xmlns()']]]
];
