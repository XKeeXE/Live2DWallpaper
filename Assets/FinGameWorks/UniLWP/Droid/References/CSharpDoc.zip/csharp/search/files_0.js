var searchData=
[
  ['adsprovider_2ecs_227',['AdsProvider.cs',['../d5/dd5/_ads_provider_8cs.html',1,'']]],
  ['androidmanifestxml_2ecs_228',['AndroidManifestXml.cs',['../d1/dda/_android_manifest_xml_8cs.html',1,'']]],
  ['androidresourcexml_2ecs_229',['AndroidResourceXml.cs',['../d2/d2b/_android_resource_xml_8cs.html',1,'']]],
  ['androidwallpaperxml_2ecs_230',['AndroidWallpaperXml.cs',['../d0/d44/_android_wallpaper_xml_8cs.html',1,'']]]
];
