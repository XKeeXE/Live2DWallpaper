var searchData=
[
  ['changelog_369',['CHANGELOG',['../d2/d4c/md__assets__fin_game_works__uni_l_w_p__droid__c_h_a_n_g_e_l_o_g.html',1,'']]]
];
