var searchData=
[
  ['instance_376',['Instance',['../d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton.html#ae19167ac324a2cd6e161f15d1822adaf',1,'FinGameWorks.UniLWP.Droid.Scripts.Managers.Fingleton.Instance()'],['../d7/d71/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_mono_injecter_droid.html#af67f739f23a53a5df04e838c95962ed9',1,'FinGameWorks.UniLWP.Droid.Scripts.Managers.LiveWallpaperMonoInjecterDroid.Instance()'],['../d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html#a928f0a232f50d43a7e9cdaf7cf43d338',1,'FinGameWorks.UniLWP.Droid.Scripts.Managers.Singleton.Instance()']]]
];
