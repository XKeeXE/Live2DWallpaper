var searchData=
[
  ['name_113',['Name',['../db/df9/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_manifest_meta_data.html#a173752a6eff3a90b973cfe296db70771',1,'FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidManifestMetaData.Name()'],['../dc/d9b/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_entry.html#a719a88b9a0cfec60fd9fba44118b37ca',1,'FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidResourceStringEntry.Name()']]]
];
