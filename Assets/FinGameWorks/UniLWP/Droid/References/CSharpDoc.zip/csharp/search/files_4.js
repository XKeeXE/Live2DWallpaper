var searchData=
[
  ['livewallpapermanagerdroid_2ecs_239',['LiveWallpaperManagerDroid.cs',['../da/dae/_live_wallpaper_manager_droid_8cs.html',1,'']]],
  ['livewallpapermonoinjecterdroid_2ecs_240',['LiveWallpaperMonoInjecterDroid.cs',['../dd/d72/_live_wallpaper_mono_injecter_droid_8cs.html',1,'']]]
];
