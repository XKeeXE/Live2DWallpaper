var searchData=
[
  ['resourcesmipmapprovider_2ecs_245',['ResourcesMipmapProvider.cs',['../d5/d4f/_resources_mipmap_provider_8cs.html',1,'']]],
  ['resourcesprovider_2ecs_246',['ResourcesProvider.cs',['../de/dcd/_resources_provider_8cs.html',1,'']]],
  ['resourcesscreensaverprovider_2ecs_247',['ResourcesScreensaverProvider.cs',['../d4/d2e/_resources_screensaver_provider_8cs.html',1,'']]],
  ['resourcesstringprovider_2ecs_248',['ResourcesStringProvider.cs',['../de/d6f/_resources_string_provider_8cs.html',1,'']]],
  ['resourceswallpaperprovider_2ecs_249',['ResourcesWallpaperProvider.cs',['../d1/d0d/_resources_wallpaper_provider_8cs.html',1,'']]]
];
