var indexSectionsWithContent =
{
  0: "abcdefgijlmnopqrstuvwx",
  1: "abeflmprsu",
  2: "f",
  3: "abeflmprsu",
  4: "abcdefgilmoprstw",
  5: "abcdijlmnoprstvwx",
  6: "o",
  7: "s",
  8: "lu",
  9: "iq",
  10: "flu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Properties",
  10: "Events"
};

