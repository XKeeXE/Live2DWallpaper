var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider =
[
    [ "BehaviorProvider", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#a1688fa4da4187e79816ec6f23fe8faa5", null ],
    [ "CreateMyCustomSettingsProvider", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#a5cc4088f8f3b997d86964442ae0ccda3", null ],
    [ "GetManifestPath", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#a54a4b2a8f4ece3ba6ef37cfea222443b", null ],
    [ "LoadXML", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#af0023c1338fd9d5f19163df202c7673e", null ],
    [ "ManifestExist", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#ab2c5e0a15c16f7b4162e6ec63506cdce", null ],
    [ "ResetXML", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#a190e8b1c0497b3251088e775f5417c6b", null ],
    [ "SaveXML", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#ac33acb5560bca98d02e997240ad5ac2f", null ],
    [ "AndroidManifest", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#a9b79c7bc48381ddf863ae74a3ebd4d63", null ],
    [ "ManifestPathRelative", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#a39ff986a29a88461ca08a8e0986ec595", null ],
    [ "Path", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html#a2d91e1dab1cdbf3210fe6acd31e18f93", null ]
];