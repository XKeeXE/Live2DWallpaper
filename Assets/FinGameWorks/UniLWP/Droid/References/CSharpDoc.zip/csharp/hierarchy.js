var hierarchy =
[
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidManifestApplication", "d0/db9/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_manifest_application.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidManifestMetaData", "db/df9/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_manifest_meta_data.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidManifestXml", "d0/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_manifest_xml.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidResourceStringEntry", "dc/d9b/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_entry.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidResourceStringXml", "d5/d0a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_xml.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.AndroidWallpaperXml", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html", null ],
    [ "EditorWindow", null, [
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Windows.MenuActions", "dc/dee/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_windows_1_1_menu_actions.html", null ]
    ] ],
    [ "FinGameWorks.UniLWP.Droid.Scripts.Datas.Enums", "d2/de9/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_datas_1_1_enums.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Helpers.FileUtils", "df/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_helpers_1_1_file_utils.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Scripts.Managers.Fingleton< LiveWallpaperManagerDroid >", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton.html", [
      [ "FinGameWorks.UniLWP.Droid.Scripts.Managers.LiveWallpaperManagerDroid", "d9/d1e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_manager_droid.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "FinGameWorks.UniLWP.Droid.Demo.Scripts.Controllers.UIController", "da/d8d/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_demo_1_1_scripts_1_1_controllers_1_1_u_i_controller.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Scripts.Managers.LiveWallpaperMonoInjecterDroid", "d7/d71/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_mono_injecter_droid.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Scripts.Managers.Singleton< T >", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html", null ]
    ] ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.PreferenceProvider", "d1/d85/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_preference_provider.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Helpers.ProjectUtils", "da/dab/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_helpers_1_1_project_utils.html", null ],
    [ "ScriptableObject", null, [
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Datas.BuildPathInfo", "d2/d3a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_build_path_info.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Scripts.Managers.FingletonBase", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base.html", [
        [ "FinGameWorks.UniLWP.Droid.Scripts.Managers.Fingleton< T >", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton.html", null ]
      ] ]
    ] ],
    [ "SettingsProvider", null, [
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.AdsProvider", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.BehaviorProvider", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.BuildAdvancedProvider", "d4/db0/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_advanced_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.BuildProvider", "d2/d2c/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.BuildSimpleProvider", "d4/df6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.MainProvider", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.ResourcesMipmapProvider", "db/d25/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_mipmap_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.ResourcesProvider", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.ResourcesScreensaverProvider", "d0/d96/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_screensaver_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.ResourcesStringProvider", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.ResourcesWallpaperProvider", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html", null ],
      [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Settings.SimulatorProvider", "de/d8a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_simulator_provider.html", null ]
    ] ],
    [ "Singleton", null, [
      [ "FinGameWorks.UniLWP.Droid.Scripts.Managers.Singleton< T >", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html", null ]
    ] ],
    [ "FinGameWorks.UniLWP.Droid.Editor.Scripts.Helpers.StringUtils", "da/de9/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_helpers_1_1_string_utils.html", null ],
    [ "FinGameWorks.UniLWP.Droid.Scripts.UniLWP", "dd/d44/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_uni_l_w_p.html", null ]
];