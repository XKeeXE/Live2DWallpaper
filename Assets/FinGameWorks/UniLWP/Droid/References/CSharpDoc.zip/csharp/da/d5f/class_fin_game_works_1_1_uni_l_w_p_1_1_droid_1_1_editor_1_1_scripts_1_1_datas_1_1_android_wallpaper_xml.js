var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml =
[
    [ "AndroidWallpaperXml", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#ac184ebdde39f1c19cf3fc395ebdf0d54", null ],
    [ "AndroidWallpaperXml", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a2f3eb22d3637da435c55abc58b59c476", null ],
    [ "AndroidWallpaperXml", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a0bc292219ac3b3719212b91357b69416", null ],
    [ "AndroidWallpaperXml", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a3fc56b6544a22ae190e487eb6c276afe", null ],
    [ "ToAPI25", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a42b300a5d378a39d56ea6de441ac268a", null ],
    [ "ToAPI29", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#af774943048a2b576c0e0b997ed240cf7", null ],
    [ "ToAPIDefault", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a59374b45a3477d8029eb58bb38bc59b9", null ],
    [ "Author", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a70352a7be93f38c9f66a75c5b193753f", null ],
    [ "ContextDescription", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a5ff624f71b9097f35c04d208c3fa58ba", null ],
    [ "ContextUri", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a82b891836ca5ead4c4b1196d0bc214a3", null ],
    [ "Description", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a76ff337b5aa08de47be1a850a084ef8a", null ],
    [ "Label", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#aa36204211f4ce903efe2c05d5b2dd894", null ],
    [ "SettingsActivity", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a49c3e1e5114846aadbcccc13d361f184", null ],
    [ "SettingsSliceUri", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#ac1b71ba6009f513271ef95be9d05d1df", null ],
    [ "ShowMetadataInPreview", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#ab2a76a5a56cbc1403d58beb6ebcd8aad", null ],
    [ "Thumbnail", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a281e589434aa8ede634b74dd90150c96", null ],
    [ "xmlns", "da/d5f/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_wallpaper_xml.html#a7fca00a5d7d346bb34e03fd3cac4bd00", null ]
];