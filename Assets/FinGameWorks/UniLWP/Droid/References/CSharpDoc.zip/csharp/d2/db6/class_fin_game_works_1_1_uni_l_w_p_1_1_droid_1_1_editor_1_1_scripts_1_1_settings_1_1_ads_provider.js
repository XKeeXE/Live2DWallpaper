var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider =
[
    [ "AdsProvider", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider.html#a3601e46941d066bb3c58bd0ff0466299", null ],
    [ "CreateMyCustomSettingsProvider", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider.html#a5bd44004636d30b0548d70c798fecc13", null ],
    [ "IsAdsEnabled", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider.html#aa10ea9fd47729240fe64302763fb4e30", null ],
    [ "SetAdsFlag", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider.html#a5ee1e6186e2facd35bb67b2d9dd25493", null ],
    [ "Path", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider.html#a6673b6a554b28a6beefa7dc55619fec3", null ]
];