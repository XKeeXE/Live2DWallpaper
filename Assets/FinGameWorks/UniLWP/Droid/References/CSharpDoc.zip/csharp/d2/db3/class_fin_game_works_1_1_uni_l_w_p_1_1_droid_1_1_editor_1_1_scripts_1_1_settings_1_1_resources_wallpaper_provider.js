var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider =
[
    [ "ResourcesWallpaperProvider", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#ae8102618a0ff27922953c0d998e751ce", null ],
    [ "CreateMyCustomSettingsProvider", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a417d27ae864ad48d868ad1cd1e57228d", null ],
    [ "GetWallpaperXmlPath", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a5b74ba56d039319d882d5737e4d5d71e", null ],
    [ "LoadXML", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#ae9445cc3e39eacc8e7d665bef3581a42", null ],
    [ "ResetXML", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#ae1070d5125938635314d36f60a623085", null ],
    [ "SaveXML", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a9ccb182c941e2f493caef956cd49d166", null ],
    [ "WallpaperXmlExist", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a05c7db0c863c139b4f04caf6881010e4", null ],
    [ "AndroidWallpaper", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a3d96a47481cd5a512c6f71940872d313", null ],
    [ "Path", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#acd81f17b1e649e1a54fe8945d45d4aed", null ],
    [ "WallpaperXmlDefaultPathRelative", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a25f1e9e855520af785e8129dec856b91", null ],
    [ "WallpaperXmlTemplatePathRelative", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a9e860bf3576aaac6194a928f843b5376", null ],
    [ "WallpaperXmlV25PathRelative", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#a2025d6f921a2db4dc9d89229b19830ad", null ],
    [ "WallpaperXmlV29PathRelative", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html#ac4f2147ccddd40e8e5b0b92880031494", null ]
];