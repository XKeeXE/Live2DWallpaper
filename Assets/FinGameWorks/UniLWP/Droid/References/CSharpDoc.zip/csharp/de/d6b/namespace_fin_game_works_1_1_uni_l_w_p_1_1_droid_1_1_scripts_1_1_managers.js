var namespace_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers =
[
    [ "Fingleton", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton.html", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton" ],
    [ "FingletonBase", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base.html", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base" ],
    [ "LiveWallpaperManagerDroid", "d9/d1e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_manager_droid.html", null ],
    [ "LiveWallpaperMonoInjecterDroid", "d7/d71/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_mono_injecter_droid.html", "d7/d71/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_mono_injecter_droid" ],
    [ "Singleton", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton" ]
];