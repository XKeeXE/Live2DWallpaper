var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton =
[
    [ "CreateInstance", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton.html#aa4626c54f663e2466757aa57cf1fe396", null ],
    [ "Instance", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton.html#ae19167ac324a2cd6e161f15d1822adaf", null ]
];