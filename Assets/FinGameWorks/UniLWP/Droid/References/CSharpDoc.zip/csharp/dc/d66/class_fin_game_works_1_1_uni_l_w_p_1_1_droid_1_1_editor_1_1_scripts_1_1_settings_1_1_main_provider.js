var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider =
[
    [ "MainProvider", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html#af62566b34259df8181c3848067f32bc9", null ],
    [ "CreateMyCustomSettingsProvider", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html#aac11a4f847d945f426a91a7e61cad45e", null ],
    [ "CSharpDocZipRelativePath", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html#a4726da1d3295ef59d7f057bf216aaf16", null ],
    [ "JavaDocZipRelativePath", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html#aed6740cdc4f2852bca7dca6b2f616d95", null ],
    [ "JavaSourceRelativePath", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html#a9f62de4eb82753a561031c74ed76eaf8", null ],
    [ "Path", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html#a1c01915c80cee3f2c0807caef35fa5cf", null ],
    [ "PdfTutorialRelativePath", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html#a791eaa3705e8bf36ad40f5b3af5ba11e", null ]
];