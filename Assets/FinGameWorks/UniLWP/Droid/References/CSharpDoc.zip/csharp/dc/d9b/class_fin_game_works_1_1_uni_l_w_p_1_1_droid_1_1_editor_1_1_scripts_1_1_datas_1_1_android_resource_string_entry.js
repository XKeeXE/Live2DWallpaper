var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_entry =
[
    [ "AndroidResourceStringEntry", "dc/d9b/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_entry.html#afad042f318bdbc8579efd856129f9a1b", null ],
    [ "AndroidResourceStringEntry", "dc/d9b/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_entry.html#a3ad7b67d5b24f332f5b1d6d43bec5d4d", null ],
    [ "Name", "dc/d9b/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_entry.html#a719a88b9a0cfec60fd9fba44118b37ca", null ],
    [ "Value", "dc/d9b/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_datas_1_1_android_resource_string_entry.html#a36f0cbf6aa20d583810f3aa74bb40687", null ]
];