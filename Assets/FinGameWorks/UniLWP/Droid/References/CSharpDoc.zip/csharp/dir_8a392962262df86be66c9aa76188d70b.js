var dir_8a392962262df86be66c9aa76188d70b =
[
    [ "AdsProvider.cs", "d5/dd5/_ads_provider_8cs.html", [
      [ "AdsProvider", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider.html", "d2/db6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_ads_provider" ]
    ] ],
    [ "BehaviorProvider.cs", "d1/d42/_behavior_provider_8cs.html", [
      [ "BehaviorProvider", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider.html", "d5/dbc/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_behavior_provider" ]
    ] ],
    [ "BuildAdvancedProvider.cs", "dc/d76/_build_advanced_provider_8cs.html", [
      [ "BuildAdvancedProvider", "d4/db0/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_advanced_provider.html", "d4/db0/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_advanced_provider" ]
    ] ],
    [ "BuildProvider.cs", "d6/dc8/_build_provider_8cs.html", [
      [ "BuildProvider", "d2/d2c/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_provider.html", "d2/d2c/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_provider" ]
    ] ],
    [ "BuildSimpleProvider.cs", "dd/d49/_build_simple_provider_8cs.html", [
      [ "BuildSimpleProvider", "d4/df6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider.html", "d4/df6/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_build_simple_provider" ]
    ] ],
    [ "MainProvider.cs", "d4/d91/_main_provider_8cs.html", [
      [ "MainProvider", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider.html", "dc/d66/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_main_provider" ]
    ] ],
    [ "PreferenceProvider.cs", "dc/d64/_preference_provider_8cs.html", [
      [ "PreferenceProvider", "d1/d85/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_preference_provider.html", null ]
    ] ],
    [ "ResourcesMipmapProvider.cs", "d5/d4f/_resources_mipmap_provider_8cs.html", "d5/d4f/_resources_mipmap_provider_8cs" ],
    [ "ResourcesProvider.cs", "de/dcd/_resources_provider_8cs.html", [
      [ "ResourcesProvider", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider.html", "d4/d43/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_provider" ]
    ] ],
    [ "ResourcesScreensaverProvider.cs", "d4/d2e/_resources_screensaver_provider_8cs.html", [
      [ "ResourcesScreensaverProvider", "d0/d96/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_screensaver_provider.html", "d0/d96/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_screensaver_provider" ]
    ] ],
    [ "ResourcesStringProvider.cs", "de/d6f/_resources_string_provider_8cs.html", [
      [ "ResourcesStringProvider", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider" ]
    ] ],
    [ "ResourcesWallpaperProvider.cs", "d1/d0d/_resources_wallpaper_provider_8cs.html", [
      [ "ResourcesWallpaperProvider", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider.html", "d2/db3/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_wallpaper_provider" ]
    ] ],
    [ "SimulatorProvider.cs", "de/d12/_simulator_provider_8cs.html", [
      [ "SimulatorProvider", "de/d8a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_simulator_provider.html", "de/d8a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_simulator_provider" ]
    ] ],
    [ "UtilsProvider.cs", "d4/dc6/_utils_provider_8cs.html", null ]
];