var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base =
[
    [ "CreateInstance", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base.html#a832bfdda3dd5f817afea04e6fc18a94b", null ],
    [ "GetOrCreate< T >", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base.html#a27854afc75f09f3114e12375bf157789", null ],
    [ "Initialize", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base.html#aedce31718049b9e09aa0402baf62659f", null ]
];