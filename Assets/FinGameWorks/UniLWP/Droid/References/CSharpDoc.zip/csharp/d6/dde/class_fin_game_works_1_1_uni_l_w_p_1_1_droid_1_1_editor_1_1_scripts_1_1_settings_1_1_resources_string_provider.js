var class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider =
[
    [ "ResourcesStringProvider", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#a1b594613a31f940cfca33ca2041b13a0", null ],
    [ "CreateMyCustomSettingsProvider", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#aedb03d657b9a62ee34a81c7b03491e4d", null ],
    [ "GetStringsXmlPath", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#abbdf5de4e55c62cbab2fb2fe4caa1f98", null ],
    [ "LoadXML", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#a5cdf2ce4751c48fd1974ca49ab419881", null ],
    [ "ResetXML", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#ace015cd9f86ad747c19c22571fdde8d8", null ],
    [ "SaveXML", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#abf53a11c9f40eb8c4a8700ce26424904", null ],
    [ "StringsXmlExist", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#a0fc916454eedb190545109e9ac630775", null ],
    [ "AndroidResourceString", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#a053c02d0414168922929c80b967ba4ea", null ],
    [ "Path", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#a9a04dedcf7f03b910a93e220405096ba", null ],
    [ "StringsXmlPathRelative", "d6/dde/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_editor_1_1_scripts_1_1_settings_1_1_resources_string_provider.html#a2e483abfc88c98164a3eb6297216f067", null ]
];