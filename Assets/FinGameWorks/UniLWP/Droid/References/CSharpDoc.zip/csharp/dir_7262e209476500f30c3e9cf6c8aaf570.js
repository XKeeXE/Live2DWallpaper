var dir_7262e209476500f30c3e9cf6c8aaf570 =
[
    [ "Fingleton.cs", "d4/df7/_fingleton_8cs.html", [
      [ "Fingleton", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton.html", "d1/d9a/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton" ],
      [ "FingletonBase", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base.html", "d6/d3e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_fingleton_base" ]
    ] ],
    [ "LiveWallpaperManagerDroid.cs", "da/dae/_live_wallpaper_manager_droid_8cs.html", [
      [ "LiveWallpaperManagerDroid", "d9/d1e/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_manager_droid.html", null ]
    ] ],
    [ "LiveWallpaperMonoInjecterDroid.cs", "dd/d72/_live_wallpaper_mono_injecter_droid_8cs.html", [
      [ "LiveWallpaperMonoInjecterDroid", "d7/d71/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_mono_injecter_droid.html", "d7/d71/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_live_wallpaper_mono_injecter_droid" ]
    ] ],
    [ "Singleton.cs", "db/d00/_singleton_8cs.html", [
      [ "Singleton", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton" ],
      [ "Singleton", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton.html", "d4/dcb/class_fin_game_works_1_1_uni_l_w_p_1_1_droid_1_1_scripts_1_1_managers_1_1_singleton" ]
    ] ]
];